<!-- generado desde foundations/cards-border-radius.html · Rappi 8 · 2026-09-30 — no editar a mano -->

# Cards/Border Radius

> **Fuente: sitio Mustache (contexto).** Si un nombre o valor de este archivo choca con `SKILL.md`, `references/*.md` o `assets/tokens.css`, ganan esos. Avisa de la diferencia.
>
> ⚠️ **Nombres heredados.** `borderRadius1…8` no existen como tokens. En Figma son primitivos (`borderRadius/4…32`); los únicos semánticos son `card` (24) y `pill`. Nombra el valor en px y marca "⚠️ sin token semántico".

El uso de tarjetas o contenedores en nuestros diseños es la manera más sencilla de integrar y organizar imágenes, textos, botones y listas.

## Cards/Border Radius

El uso de tarjetas o contenedores en nuestros diseños, es la manera más sencilla de integrar y organizar imágenes, textos, botones, listas, etc.

### Anatomy

On top of white background — lightmode. On top of black background — darkmode.

## Card Scale/Border Radius

Al momento de usar una card para la construcción de un componente, es necesario tener en cuenta que el "Border radius" de esta se adaptará según la interfaz de usuario.

Hay que tener en cuenta que el tamaño de una Card siempre está en una escala de 4px min. a 32px máx.

| Token | Border Radius |
| --- | --- |
| borderRadius1 | 4px |
| borderRadius2 | 8px |
| borderRadius3 | 12px |
| borderRadius4 | 16px |
| borderRadius5 | 20px |
| borderRadius6 | 24px |
| borderRadius7 | 28px |
| borderRadius8 | 32px |
