<!-- generado desde foundations/haptics.html · Rappi 8 · 2026-10-01 — no editar a mano -->

# Haptics

> **Fuente: sitio Mustache (contexto).** Si un nombre o valor de este archivo choca con `SKILL.md`, `references/*.md` o `assets/tokens.css`, ganan esos. Avisa de la diferencia.
>
> ⚠️ **Borrador.** Nomenclatura y varios casos están "por confirmar". Úsalo como criterio, no como spec cerrada.

Cómo Mustache usa la vibración del dispositivo para confirmar, advertir y dar textura física a las interacciones de Rappi, siempre de forma consistente y como refuerzo de lo que la persona ya ve y oye.

- **Estado** En construcción

- **Versión** 0.1

## Overview

Un haptic es cualquier respuesta física que la persona siente en el cuerpo a través del dispositivo, normalmente una vibración corta. Estimula el sentido del tacto para **transmitir y reforzar** acciones puntuales dentro de la app.

Por qué le importa a Rappi:

- **Comunica sin molestar a otros.** El teléfono avisa a quien lo tiene en la mano, sin sonido ni alerta visible para los demás.

- **Funciona cuando no se mira la pantalla.** Un Rappitendero en movimiento o bajo sol directo recibe la confirmación aunque no alcance a leerla.

- **Es un canal poco aprovechado.** Frente a la señal visual y de audio, el tacto es la forma de interacción más cercana al cuerpo, y la mayoría de productos aún no la usa con intención.

- **Sin estándar, se vuelve ruido.** Hoy no existe un estándar de haptics para toda la industria. Si cada equipo elige su propia vibración, la misma sensación puede significar "listo" en una app y "error" en otra.

## Key terms

| Término | Qué significa |
| --- | --- |
| Haptic del sistema | Patrón predefinido por iOS o Android. Es la opción por defecto en Mustache. |
| Haptic personalizado | Patrón diseñado a mano (Core Haptics en iOS, composiciones en Android). Solo se usa si el sistema no cubre el caso. |
| Fuerza | Qué tan fuerte se siente la vibración. En iOS se divide en nitidez e intensidad; en Android se llama amplitud. |
| Comportamiento | El patrón de la vibración: un toque, dos toques, una vibración larga. |
| Nitidez (iOS) | Si la vibración se siente estrecha y precisa, o difusa. |
| Intensidad (iOS) | Qué tan fuerte es el golpe. |
| Amplitud (Android) | La fuerza del haptic. Los mensajes importantes pueden ser más fuertes y con un patrón más largo. |

## Principles

- **Causa y efecto clara.** Cada haptic tiene un disparador que la persona reconoce. Por qué: si la vibración no responde a algo que la persona hizo o vio, se siente gratuita y confunde.

- **Refuerza, nunca reemplaza.** El haptic acompaña una señal visual o sonora, o un gesto (scroll, pulsación larga, transacción). Por qué: cuando lo visual, lo sonoro y lo táctil van en armonía, la experiencia se siente natural, como en el mundo físico.

- **Con prudencia.** Pocas interacciones importantes y con consecuencia, no muchas triviales. Por qué: usarlos para agregar novedad hace que la app se sienta efectista y termina abrumando.

- **Mismo patrón, mismo significado.** Un patrón se asocia siempre al mismo tipo de resultado, en todas las apps de Rappi. Por qué: la gente aprende asociaciones táctiles; si el patrón de "error" aparece en un éxito, se rompe la confianza.

- **Sistema primero.** Usa los patrones nativos de cada plataforma y crea patrones propios solo cuando el sistema no tenga uno que encaje. Por qué: la persona ya los conoce del resto de su teléfono.

- **Opcional y respetuoso.** Respeta el ajuste de haptics del sistema y deja que la persona los apague; la app debe funcionar igual de bien sin ellos. Por qué: la sensibilidad a la vibración varía mucho entre personas.

## Types

Mustache trabaja con **tres tipos** de haptic, heredados de las familias de feedback de iOS y mapeados a su equivalente en Android.

> **Por confirmar:** diagrama nitidez vs. intensidad, tomado del tablero FigJam `haptics-rappi`.

| Tipo | Para qué | iOS | Android (tablero actual) | Android (recomendado) |
| --- | --- | --- | --- | --- |
| selection | Feedback mientras cambia el valor de un elemento de UI (elegir toppings, agregar a la canasta, stepper) | `UISelectionFeedbackGenerator` | `EFFECT_TICK` | `SEGMENT_TICK` / `CLOCK_TICK` |
| notification · success | Una tarea o acción se completó | `UINotificationFeedbackGenerator .success` | `EFFECT_CLICK` | `CONFIRM` |
| notification · warning | La acción produjo una advertencia | `UINotificationFeedbackGenerator .warning` | `EFFECT_CLICK` | [por definir] (no hay constante nativa de advertencia) |
| notification · error | La tarea o acción falló | `UINotificationFeedbackGenerator .error` | `EFFECT_CLICK` | `REJECT` |
| impact | Metáfora física que complementa algo visual (una vista que encaja en su lugar, un toggle) | `UIImpactFeedbackGenerator` (estilo `medium` para toggles) | [por definir] | `TOGGLE_ON` / `TOGGLE_OFF` para toggles |

Constantes Android listadas en el tablero como catálogo base:

EFFECT_TICK
EFFECT_CLICK
EFFECT_HEAVY_CLICK
EFFECT_DOUBLE_CLICK

> **Nomenclatura propuesta (por confirmar):** nombrar el haptic por intención, no por plataforma: `haptic/selection`, `haptic/success`, `haptic/warning`, `haptic/error`, `haptic/impact-medium`. Cada plataforma resuelve el nombre a su API nativa, igual que un token semántico resuelve a un primitive.

## How it maps to Rappi

Mapeo de interacciones reales de la app a cada tipo. El estado refleja lo marcado en el tablero de diseño.

### selection

| Interacción | Estado |
| --- | --- |
| Agregar un producto a la canasta | Propuesto |
| Dar like a un producto o tienda | Propuesto |
| Aumentar unidades de producto (stepper) | Propuesto |
| Slider con opciones de selección (ej. madurez del producto) | Propuesto |
| Confirmar sustitutos (selección múltiple) | Propuesto |
| Activar o desactivar filtros | Propuesto |
| Filtros con selección | En revisión |
| Selección de storetype | En revisión (entrar a un storetype es navegación; no parece necesario) |
| Ir a pagar | En revisión |
| Tocar ver canasta | En revisión |
| Cerrar modales | En revisión |

### notification

| Resultado | Interacción | Estado |
| --- | --- | --- |
| success | Confirmación del código enviado al celular | Propuesto (revisar si el sistema ya vibra cuando el código llega por SMS) |
| success | Aceptar un sustituto | Propuesto |
| success | Confirmación de un pedido | Propuesto |
| warning | Intentar agregar un producto sin completar los toppings | Propuesto |
| warning | Dirección de entrega lejos de la ubicación actual | Propuesto |
| error | Código inválido al ingresarlo (ej. cupón no válido, con snackbar o microinteracción en el input) | Propuesto |
| error | Dirección de entrega errónea | Propuesto |
| warning o error | Realizar un pedido sin seleccionar método de pago | [por decidir]: aparece en ambas columnas del tablero |

### impact

| Interacción | Estilo | Estado |
| --- | --- | --- |
| Prender o apagar toggles | medium | En revisión |

### Dónde NO usar haptic (por revisar)

- Cancelar una búsqueda.

- Modales nativas con selección (el sistema ya resuelve su feedback).

- Tab bar: es un componente donde la persona se mueve mucho; apps nativas y de delivery revisadas no lo usan.

- Entrada al home o a un storetype: pendiente validar, se inclina a no usar.

## Accessibility

- **Nunca como único canal.** Todo haptic tiene su par visual (color + ícono + texto) y, cuando aplique, sonoro. Es la misma regla que en [Accessibility](accessibility.html): el color no es el único indicador de estado, y la vibración tampoco.

- **Respetar el ajuste del sistema.** Si la persona desactivó las vibraciones del sistema, la app no las fuerza (en Android, nunca usar `FLAG_IGNORE_GLOBAL_SETTING`).

- **Consistencia como apoyo real.** Muchas personas usan los haptics del sistema para saber si algo funcionó o falló cuando no pueden ver la pantalla. Usar los patrones de éxito y error de forma coherente es parte de la accesibilidad, no un extra.

- **Nada largo ni repetitivo.** Evita vibraciones prolongadas o en bucle: pueden resultar incómodas y generan fatiga.

- **No interferir con sensores.** La vibración no debe interrumpir experiencias con cámara, giroscopio o micrófono (ej. escanear un código, grabar un audio para el Rappitendero).

- **Probar con personas reales.** La sensibilidad varía; valida en dispositivos físicos iOS y Android de gama baja y alta, no solo en simulador.

## Do & Don't

- **Usar success al confirmar un pedido, junto al check y el mensaje en pantalla** — no vibres sin ningún cambio visible en la UI.

- **Usar el patrón nativo del switch del sistema** — no sumes un haptic custom a un control que ya vibra por defecto (se duplica).

- **Reservar error para fallas reales (cupón no válido)** — no uses el mismo patrón para éxito y error.

- **Un haptic corto y nítido por evento** — no uses vibraciones largas, en bucle o en cada scroll.

- **Dejar que la persona apague los haptics y que la app siga siendo clara** — no dependas del haptic para comunicar información compleja.

## Dependencies

- [Accessibility](accessibility.html): los haptics son un canal más de feedback y heredan la regla de "nunca un solo indicador".

- [Motion](motion.html): haptic y animación deben ir sincronizados (ej. el impact al encajar una vista coincide con el final de la animación). [por documentar]

- **Componentes que disparan haptics:** stepper (`button-stepper`), toggle (`switch`), slider, filtros (`tags/carousel/standard-filters`), snackbars, `inputs/PIN`. Documentar en cada ficha de componente qué haptic dispara y cuándo. [por confirmar]

- [Content](../content.html): el mensaje visual que acompaña a un warning o error sigue la guía de voz y tono.

## Open items before Stable

> **Decidir** si "pedido sin método de pago" es warning o error. **Cerrar** los ítems "En revisión" de selection (filtros con selección, ir a pagar, ver canasta, cerrar modales, storetype). **Definir** el uso de impact: el tablero lo deja en revisión porque sus niveles no tienen una intención clara para Rappi. **Validar** la migración en Android de EFFECT_* a constantes por acción (CONFIRM, REJECT, SEGMENT_TICK, TOGGLE_ON/OFF), y definir qué usar para warning. **Confirmar** con desarrollo la nomenclatura haptic/*.

## References

- Origen en Figma: FigJam **haptics-rappi** (`fileKey 5aOqmDJMcu1dsNZIIWhe94`), secciones "Haptics ¿Qué son?", "Dimensiones hápticas", "Tipos de Haptics", "Principios", "Implementación" y "Proposal Rappi experience".

- DS y guías consultadas: Apple Human Interface Guidelines (Playing haptics, Accessibility), Android Developers (Haptics design principles, Add haptic feedback to events), AOSP (UX foundation for haptic framework).

| Campo | Valor |
| --- | --- |
| Versión | 0.1 (borrador para revisión interna) |
| Propietario | Equipo de Design System, Mustache |
| Última actualización | 24 sep, 2026 |
