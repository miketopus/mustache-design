<!-- generado desde foundations/haptics.html · Rappi 8 · 2026-11-05 — no editar a mano -->

# Haptics

> **Fuente: sitio Mustache (contexto).** Si un nombre o valor de este archivo choca con `SKILL.md`, `references/*.md` o `assets/tokens.css`, ganan esos. Avisa de la diferencia.
>
> ⚠️ **Borrador.** Nomenclatura y varios casos están "por confirmar". Úsalo como criterio, no como spec cerrada.

Cómo Mustache usa la vibración del dispositivo para confirmar, advertir y dar textura física a las interacciones de Rappi, siempre de forma consistente y como refuerzo de lo que la persona ya ve y oye.

- **Estado** En construcción

- **Versión** 0.2

- **Categorías** 4

- **Casos** 0

- **Plataforma** iOS · Android por definir

## Overview

Un haptic es cualquier respuesta física que la persona siente en el cuerpo a través del dispositivo, normalmente una vibración corta. Estimula el sentido del tacto para **transmitir y reforzar** acciones puntuales dentro de la app.

Por qué le importa a Rappi:

- **Comunica sin molestar a otros.** El teléfono avisa a quien lo tiene en la mano, sin sonido ni alerta visible para los demás.

- **Funciona cuando no se mira la pantalla.** Un Rappitendero en movimiento o bajo sol directo recibe la confirmación aunque no alcance a leerla.

- **Es un canal poco aprovechado.** Frente a la señal visual y de audio, el tacto es la forma de interacción más cercana al cuerpo, y la mayoría de productos aún no la usa con intención.

- **Sin estándar, se vuelve ruido.** Hoy no existe un estándar de haptics para toda la industria. Si cada equipo elige su propia vibración, la misma sensación puede significar "listo" en una app y "error" en otra.

## Key terms

| Término | Qué significa |
| --- | --- |
| Haptic del sistema | Patrón predefinido por iOS o Android. Es la opción por defecto en Mustache. |
| Haptic personalizado | Patrón diseñado a mano (Core Haptics en iOS, composiciones en Android). Solo se usa si el sistema no cubre el caso. |
| Categoría | Para qué se usa el haptic en Rappi: Main actions, Secondary actions, Success / Warning / Error o Physical Feedback. Cada caso pertenece a una sola. |
| Patrón | La vibración concreta que suena (ej. Light impact). Vive en la Pattern library y se reutiliza entre categorías. |
| Momento | El instante exacto en que se dispara: al soltar el dedo, al presionar, al llegar al umbral de un gesto o de forma automática. |
| Nitidez (iOS) | Si la vibración se siente estrecha y precisa, o difusa. |
| Intensidad (iOS) | Qué tan fuerte es el golpe. |
| Amplitud (Android) | La fuerza del haptic. Los mensajes importantes pueden ser más fuertes y con un patrón más largo. |

## Principles

- **Causa y efecto clara.** Cada haptic tiene un disparador que la persona reconoce. Por qué: si la vibración no responde a algo que la persona hizo o vio, se siente gratuita y confunde.

- **Refuerza, nunca reemplaza.** El haptic acompaña una señal visual o sonora, o un gesto (scroll, pulsación larga, transacción). Por qué: cuando lo visual, lo sonoro y lo táctil van en armonía, la experiencia se siente natural, como en el mundo físico.

- **Con prudencia.** Pocas interacciones importantes y con consecuencia, no muchas triviales. Por qué: usarlos para agregar novedad hace que la app se sienta efectista y termina abrumando.

- **Mismo patrón, mismo significado.** Un patrón se asocia siempre al mismo tipo de resultado, en todas las apps de Rappi. Por qué: la gente aprende asociaciones táctiles; si el patrón de "error" aparece en un éxito, se rompe la confianza.

- **Sistema primero.** Usa los patrones nativos de cada plataforma y crea patrones propios solo cuando el sistema no tenga uno que encaje. Por qué: la persona ya los conoce del resto de su teléfono.

- **Opcional y respetuoso.** Respeta el ajuste de haptics del sistema y deja que la persona los apague; la app debe funcionar igual de bien sin ellos. Por qué: la sensibilidad a la vibración varía mucho entre personas.

## Categories

Todo haptic de Rappi pertenece a **una de 4 categorías**. La categoría dice **para qué** se usa; el patrón de la librería dice **cómo se siente**. Así un caso nuevo no inventa una vibración: elige categoría y reutiliza un patrón.

### Reglas comunes a todas las categorías

Momento por defecto

**Al soltar el dedo.** Solo se documenta el momento cuando es distinto (al presionar, umbral de gesto o automático).

Intensidad por defecto

**80%** en impacts y **100%** en notifications. Otro valor se marca como excepción en el caso.

Siempre con cambio visual

Ningún haptic suena solo. Si es automático, coincide con una animación o un mensaje en pantalla.

### ¿En qué categoría va un caso nuevo?

Responde en orden. La primera respuesta "sí" define la categoría.

- ¿Comunica el **resultado** de algo: éxito, alerta, error o un premio?Success / Warning / Error

- ¿Imita un **comportamiento físico**: llegar al límite de un gesto o algo que aparece e interrumpe?Physical Feedback

- ¿Hace **avanzar la compra**: agregar, ir a canasta, continuar, pagar?Main actions

- ¿Es una acción secundaria donde importa **confirmar** que ocurrió?Secondary actions

- Ninguna de las anteriores.Sin haptic

Todos los patrones

## Pattern library

Las vibraciones que usa Rappi hoy, nombradas por intención como un token semántico: `haptic/*` resuelve a la API nativa de cada plataforma, igual que un token de color resuelve a un primitive.

> **Por confirmar:** la nomenclatura `haptic/*` con desarrollo y la columna Android, que hoy es una recomendación sin validar.

## Accessibility

- **Nunca como único canal.** Todo haptic tiene su par visual (color + ícono + texto) y, cuando aplique, sonoro. Es la misma regla que en [Accessibility](accessibility.html): el color no es el único indicador de estado, y la vibración tampoco.

- **Respetar el ajuste del sistema.** Si la persona desactivó las vibraciones del sistema, la app no las fuerza (en Android, nunca usar `FLAG_IGNORE_GLOBAL_SETTING`).

- **Consistencia como apoyo real.** Muchas personas usan los haptics del sistema para saber si algo funcionó o falló cuando no pueden ver la pantalla. Usar los patrones de éxito y error de forma coherente es parte de la accesibilidad, no un extra.

- **Nada largo ni repetitivo.** Evita vibraciones prolongadas o en bucle: pueden resultar incómodas y generan fatiga.

- **No interferir con sensores.** La vibración no debe interrumpir experiencias con cámara, giroscopio o micrófono (ej. escanear un código, grabar un audio para el Rappitendero).

- **Probar con personas reales.** La sensibilidad varía; valida en dispositivos físicos iOS y Android de gama baja y alta, no solo en simulador.

## Do & Don't

### Do

- Usar success al confirmar un pedido, junto al check y el mensaje en pantalla.

- Usar el patrón nativo del switch del sistema.

- Reservar error para fallas reales (cupón no válido).

- Un haptic corto y nítido por evento.

- Dejar que la persona apague los haptics y que la app siga siendo clara.

### Don't

- Vibrar sin ningún cambio visible en la UI.

- Sumar un haptic custom a un control que ya vibra por defecto (se duplica).

- Usar el mismo patrón para éxito y error.

- Usar vibraciones largas, en bucle o en cada scroll.

- Depender del haptic para comunicar información compleja.

## Dependencies

- [Accessibility](accessibility.html): los haptics son un canal más de feedback y heredan la regla de "nunca un solo indicador".

- [Motion](motion.html): haptic y animación van sincronizados (ej. el sello de RappiRewards vibra justo cuando toca la pantalla). [por documentar]

- **Componentes que disparan haptics:** se listan en cada caso de las 4 categorías. La ficha de cada componente debe enlazar aquí su caso. [por confirmar]

- [Content](../content.html): el mensaje visual que acompaña a un warning o error sigue la guía de voz y tono.

## Open items before Stable

> **Especificar** el patrón Press & release (intensidad, nitidez y tiempos) para que no dependa de una referencia en producción. **Definir** el equivalente Android de cada patrón de la librería. **Reconciliar** esta guía con la propuesta del tablero FigJam `haptics-rappi` (stepper, filtros y propina como selection). **Decidir** si "pedido sin método de pago" es warning o error. **Confirmar** con desarrollo la nomenclatura `haptic/*`.

## References

- Fuente de las 4 categorías: Figma [Haptics & Motion · Haptics guide](https://www.figma.com/design/9swVK6lCtF6ZfjjzjrQwDX/Haptics---Motion?node-id=1-733).

- Propuesta inicial: FigJam **haptics-rappi** (`fileKey 5aOqmDJMcu1dsNZIIWhe94`).

- Guías consultadas: Apple Human Interface Guidelines (Playing haptics), Android Developers (Haptics design principles), Meta (Haptics system).

| Campo | Valor |
| --- | --- |
| Versión | 0.2 (estructura por categorías, borrador para revisión interna) |
| Propietario | Equipo de Design System, Mustache |
| Última actualización | 26 oct, 2026 |
