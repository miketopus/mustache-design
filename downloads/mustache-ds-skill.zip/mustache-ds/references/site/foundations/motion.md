<!-- generado desde foundations/motion.html · Rappi 8 · 2026-09-28 — no editar a mano -->

# Motion

El movimiento puede dar vida a la pantalla, guiar a los usuarios a través de experiencias complejas y ayudarlos a progresar.

## Motion

El movimiento puede dar vida a la pantalla, guiar a los usuarios a través de experiencias complejas y ayudarlos a avanzar, de aquí para allá, de allá a aquí, de principio a fin, y progresar.

Motion ayuda a que una interfaz de usuario sea expresiva y fácil de usar.

## Principles

- **Movimientos suaves y realistas** — Al momento de crear la animación ideal, es necesario a través de las transiciones o movimientos en una composición, narrar de forma coherente y realista el contenido para nuestras personas usuarias.

- **El timing correcto** — Aplicar de manera correcta el tiempo en una transición, permite que la información o mensaje que buscamos comunicar visualmente sea clara y coherente, evitando saltos de tiempo en la narrativa que puedan confundir a las personas usuarias.

- **Coherencia visual** — Lograr sorprender y guiar a nuestras personas usuarias a través del movimiento correcto de los elementos en una composición, aporta además de consistencia, y coherencia una atención diferencial en los contenidos de la marca.

- **Consistencia y carácter** — La personalidad de Rappi vive en todas sus interacciones y comunicaciones, por esta razón cada frame, movimiento o detalle debe reflejar su estilo solucionador, innovador y disruptivo.

## Do & Don't

- **Evita la deformación** — No distorsiones en las dimensiones de los componentes; en el caso de los elementos de aspecto "sólido" su adaptación debe darse de manera realista y controlada sin alterar la calidad visual de la pieza.

- **Aplica una velocidad realista y controlada** — Controlar la aceleración y el frenado en cada gráfica es la forma perfecta para crear en los elementos un efecto de movimiento realista y fresco; por esta razón debemos evitar aplicar acciones que puedan verse rígidas y bruscas en las composiciones.

- **Dibujos sólidos y proporcionados** — Crear objetos o composiciones que reflejen de manera realista su peso, masa o volumen nos asegura que cada diseño sea realista, consistente y pulido.

- **Crea contenidos basados en un objetivo** — El mejor contenido es aquel que guía a nuestras personas usuarias, responde a sus necesidades y tiene un objetivo de negocio; por eso, al momento de crear una animación, cuenta siempre una historia coherente y clara.
