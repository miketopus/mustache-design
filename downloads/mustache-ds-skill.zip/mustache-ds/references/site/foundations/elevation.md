<!-- generado desde foundations/elevation.html · Rappi 8 · 2026-09-30 — no editar a mano -->

# Elevation

> **Fuente: sitio Mustache (contexto).** Si un nombre o valor de este archivo choca con `SKILL.md`, `references/*.md` o `assets/tokens.css`, ganan esos. Avisa de la diferencia.
>
> ⚠️ **Borrador sin tokens.** Los niveles existen en el sitio, pero no hay valores de sombra exportados en `tokens.css`. Nombra el nivel (ej. "Elevated Strong") y marca "⚠️ sin token oficial". Nunca inventes valores de sombra como si fueran del DS.

Las elevaciones simulan el efecto visual de un elemento "flotando" sobre una superficie: sombras y orientaciones con un uso definido.

- **Estado** New

## Elevation

In Rappi the elevations, also known as shadows or orientations, are the visual effect that simulates an elevation of a "floating" element on a surface.

One of the challenges at the moment to apply on our interface the elevations are the variety of plans that are through the experiences like maps or widgets.

> En la fuente esta sección incluye un ejemplo 3D creado en Spline mostrando una elevación (contenido visual, sin texto adicional).

## Niveles de sombra y orientación en Mustache

En nuestro Sistema de Diseño contamos con 4 niveles de sombras y orientaciones para el uso correcto de las elevaciones.

A continuación, encontrarás a detalle los tipos de elevaciones y la distancia necesaria entre la capa principal para implementar de la forma correcta este efecto visual.

Recuerda, los efectos, definen su intensidad y profundidad según las sombras proyectadas en el componente aplicado.

### Styles

Las elevaciones, como todo efecto visual cuenta con diferentes tipos de aplicaciones, a continuación encontrarás los 4 tipos de elevaciones más aplicados en Rappi.

| Name style | Descripción |
| --- | --- |
| Elevated | Superposiciones contextuales, para componentes como Seleccionar y Barra de menús, tooltips. |
| Elevated Strong | Elementos más altos en el orden de apilamiento, por ejemplo, notificaciones, que deben estar por encima de cualquier otro contenido. |
| Elevated Hard | Superposiciones… |
| Elevated (-Y) | Superposiciones contextuales, para componentes anidados como navegaciones inferiores. |

> **Así está en la fuente.** La descripción de `Elevated Hard` queda cortada ("Superposiciones…") en la página original.

Es importante tener en cuenta, que en algunos componentes el uso de las elevaciones busca principalmente generar una jerarquía visual en los elementos; ejemplo de ello: la "navegación inferior" y el "botón de acción flotante".

En el caso de componentes específicos, como la navegación inferior y el botón de acción flotante, se aplican las elevaciones para otorgar una mayor jerarquía visual a los elementos. Así mismo en casos como los formularios de registro y de inicio de sesión.

## Style Buttons

Las elevaciones, como hemos podido ver en secciones anteriores son un efecto visual versátil y de alta carga semántica, sin embargo, su aplicación en los botones solo es posibles en casos específicos como los botones principales de la app.

| Name style | Descripción |
| --- | --- |
| Rappi | Elevación con el color Rappi que solo puede ser usado si la superficie del botón cumple con el mismo tono. |
| Green | Elevación con el color verde que solo puede ser usado en los botones de canasta o pagos que contengan el mismo tono en la superficie. |
| Blue | — |

> **Así está en la fuente.** La fila `Blue` no tiene descripción en la tabla original.

## Guidelines

El objetivo principal de las elevaciones, además de enfocar u otorgar una mayor jerarquía visual a cualquier componente, es igual mente simular un efecto similar al de la experiencia física que se tiene con los objetos en la realidad.

> **Nota:** al aplicar las elevaciones es importante tener en cuenta que los objetos si bien pueden apilarse, no pueden atravesarse entre sí.

### Don't

- No use elevaciones en los iconos.

- No use elevaciones en los textos.

### Aplicación de elevaciones en Figma

Al momento de buscar aplicar una "elevación" de manera individual en un cuadro de contenido, es fundamental tener en cuenta el propósito de esta aplicación.

¿Qué se necesita para aplicar de manera correcta una elevación en un contenido? Sencillo, solo es necesario aplicar el estilo de elevación deseado en rectángulo que sea similar, en tamaño, al cuadro de texto el cual se busca mejorar y listo.

Para encontrar todas nuestras variables de "elevaciones" es necesario conectar Foundations, nuestra librería CORE, con la aplicación de Figma y usarla a través de capas que se pueden aplicar fácilmente en los elementos a intervenir.

## Elevaciones por defecto

Todos los elementos tienen valores predeterminados, en el caso de la elevación de reposo o los desplazamientos dinámicos; esto se ve reflejado en su jerarquía.

Un ejemplo de lo mencionado anteriormente son: los cuadros de diálogo que sobreponen a otros componentes en una interfaz.

La siguiente tabla organiza los valores predeterminados según la elevación necesaria para el reposo y los desplazamientos dinámicos de cada componente.

| Component | Valor de elevación predeterminado |
| --- | --- |
| Button Basket | Green |
| Button Checkout | Green |
| Pricing Tables | Hard |
| Notifications flotantes | Strong |
| Pop-ups | Strong |
| FAB (floating action button) | Strong |

### Soporte para elevaciones

Las elevaciones siguen una lógica simple: a mayor número en la elevación, más evidente es la sombra.

En el caso puntual de algunas elevaciones, estás vienen de manera similar a una combinación de dos colores en su estilo, por ejemplo: Elevation Hard.
