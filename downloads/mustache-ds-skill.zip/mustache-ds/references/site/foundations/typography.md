<!-- generado desde foundations/typography.html · Rappi 8 · 2026-09-29 — no editar a mano -->

# Typography

La tipografía da voz al sistema. Una sola familia, dos pesos y una escala predecible que mantiene la jerarquía consistente en toda la interfaz.

- **Familia** PP Object Sans

- **Pesos** Regular · Medium

## Familia tipográfica

Mustache usa **PP Object Sans** como única familia. Una sola tipografía en todo el sistema mantiene la marca reconocible y reduce la carga de decisiones al diseñar.

Aa Bb Cc 0123

PP Object Sans

> **Nota:** PP Object Sans no está en Google Fonts, así que estos especímenes se muestran con la fuente del sitio como aproximación. El render final usa PP Object Sans embebida.

## Pesos

El sistema trabaja con dos pesos. **Medium (500) reemplazó a Bold** como el peso de énfasis: da jerarquía sin sentirse pesado, alineado con el tono fresco y directo de la marca.

Regular
font/weight/Regular · 400

Medium
font/weight/Medium · 500

## Escala tipográfica

Cada estilo es un token que combina familia, peso, tamaño, interlineado y tracking. Estos son los estilos que pude leer del nodo seleccionado en Figma:

Huge Title

titles / hugeTitleMediumPP Object Sans · Medium 50048 / 48 · tracking 0

Body Medium — el texto base de la interfaz.

body / bodyMediumPP Object Sans · Medium 50016 / 20 · tracking 0

Caption Regular — texto de apoyo y metadatos.

caption / caption1RegularPP Object Sans · Regular 40014 / 16 · tracking 0

> **Escala parcial.** Estos 3 estilos vienen del nodo que estaba seleccionado. La escala completa (titles, headings, body, caption con todos sus tamaños) sale del frame de tipografía en Figma: selecciónalo y lo lleno con todos los estilos y specs exactos.
