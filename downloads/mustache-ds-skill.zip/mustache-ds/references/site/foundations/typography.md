<!-- generado desde foundations/typography.html · Rappi 8 · 2026-10-01 — no editar a mano -->

# Typography

> **Fuente: sitio Mustache (contexto).** Si un nombre o valor de este archivo choca con `SKILL.md`, `references/*.md` o `assets/tokens.css`, ganan esos. Avisa de la diferencia.

La tipografía da voz al sistema. Una familia para la interfaz, dos pesos y una escala por breakpoint que mantiene la jerarquía consistente en toda la app.

- **Familia** PP Object Sans

- **Pesos** Regular · Medium

- **Text styles** 39

- **Breakpoints** Mobile · Tablet · Desktop

## Familias tipográficas

**PP Object Sans** es la familia de la interfaz: títulos y contenido. **Archivo Black** es exclusiva del componente **banner-bigFont** (`hugeTitle*`): no es una fuente display general ni se usa en ninguna otra pieza.

Aa Bb Cc 0123

PP Object Sans · interfaz

Aa Bb Cc 0123

Archivo Black · solo banner-bigFont

| Variable | Valor | Uso |
| --- | --- | --- |
| PP Object sans/family/title | PP Object Sans | huge a subheadline |
| PP Object sans/family/content | PP Object Sans | body a legal |
| Archivo Black/family/title | Archivo Black | Solo banner-bigFont (hugeTitleL · M · S) |

> **Nota:** PP Object Sans no está en Google Fonts, así que estos especímenes se muestran con la fuente del sitio como aproximación. El render final usa PP Object Sans embebida.

## Pesos

El sistema trabaja con dos pesos. **Medium (500) reemplazó a Bold** como el peso de énfasis: da jerarquía sin sentirse pesado, alineado con el tono fresco y directo de la marca.

Regular
PP Object sans/weight/Regular · 400

Medium
PP Object sans/weight/Medium · 500

> **Legado:** los text styles `*Bold` (700) siguen en Figma para no romper archivos existentes, y la variable `weight/Heavy` existe sin text style. No los uses en diseño nuevo.

## Escala tipográfica

Cada rol combina familia, peso, tamaño, interlineado y tracking. Tamaño e interlineado cambian por breakpoint: **Mobile** (<600px), **Tablet** (≥600px) y **Desktop** (≥1024px). Especímenes en Mobile.

Huge

huge/hugeMediumPP Object Sans · Medium 50048 / 48 · tracking 0

H1

h1/h1MediumPP Object Sans · Medium 50040 / 40 · tracking 0

H2

h2/h2MediumPP Object Sans · Medium 50032 / 40 · tracking 0

H3

h3/h3MediumPP Object Sans · Medium 50026 / 32 · tracking 0

H4

h4/h4MediumPP Object Sans · Medium 50024 / 32 · tracking 0

Headline

headline/headlineMediumPP Object Sans · Medium 50020 / 24 · tracking 0

Eyebrow de sección

subheadline/subheadlineMediumPP Object Sans · Medium 50010 / 24 · tracking 12% · mayúsculas

Body: el texto base de la interfaz.

body/bodyRegularPP Object Sans · Regular 40016 / 20 · tracking 0

Caption 1: texto de apoyo y metadatos.

caption-1/caption1RegularPP Object Sans · Regular 40014 / 16 · tracking 0

Caption 2: metadatos secundarios.

caption-2/caption2RegularPP Object Sans · Regular 40012 / 16 · tracking 0

Label: tags y badges

label/labelRegularPP Object Sans · Regular 40010 / 12 · tracking 0

### Tabla completa por breakpoint

| Rol | Mobile | Tablet | Desktop | Pesos |
| --- | --- | --- | --- | --- |
| huge | 48 / 48 | 64 / 72 | 64 / 72 | Bold · Medium · Regular |
| h1 | 40 / 40 | 28 / 34 | 40 / 48 | Bold · Medium · Regular |
| h2 | 32 / 40 | 24 / 32 | 32 / 40 | Bold · Medium · Regular |
| h3 | 26 / 32 | 20 / 28 | 24 / 32 | Bold · Medium · Regular |
| h4 | 24 / 32 | 18 / 26 | 20 / 26 | Bold · Medium · Regular |
| headline | 20 / 24 | 20 / 24 | 18 / 24 | Bold · Medium · Regular |
| subheadline | 10 / 24 | 10 / 16 | 10 / 24 | Bold · Medium · Regular |
| body | 16 / 20 | 16 / 24 | 16 / 24 | Bold · Medium · Regular |
| caption-1 | 14 / 16 | 14 / 20 | 14 / 20 | Bold · Medium · Regular |
| caption-2 | 12 / 16 | 12 / 18 | 12 / 18 | Bold · Medium · Regular |
| label | 10 / 12 | 10 / 14 | 10 / 16 | Bold · Medium · Regular |
| footnote | 8 / 12 | 8 / 12 | 8 / 12 | Regular |
| disclaimer | 6 / 8 | 6 / 8 | 6 / 8 | Regular |
| legal | 4 / 6 | 4 / 6 | 4 / 6 | Regular |

> **Legibilidad:** cuerpo mínimo 16px (`body`) y 12px en UI (`caption-2`). `footnote` (8), `disclaimer` (6) y `legal` (4) existen en Figma pero son ilegibles en pantalla: si un legal lo exige, usa `caption-2`.

## Archivo Black · banner-bigFont

Archivo Black **solo vive en el componente banner-bigFont** (mobile-library Rappi 8), para la cifra o titular protagonista, como el % OFF. El resto del texto del banner va en PP Object Sans. No la uses en otros banners, pantallas ni piezas de marketing: ahí usa `huge` o `h1`.

Tracking **−4%** e interlineado menor que el tamaño, a propósito: titulares de 1 o 2 líneas.

          -50% hoy

Archivo-Black/hugeTitleL46/34 · 52/40 · 64/48tracking −4%

          -50% hoy

Archivo-Black/hugeTitleM40/32 · 48/34 · 56/40tracking −4%

          -50% hoy

Archivo-Black/hugeTitleS30/26 · 32/28 · 46/34tracking −4%

| Estilo | Cuándo usarlo dentro del bigFont |
| --- | --- |
| hugeTitleL | El protagonista: la cifra estrella (precio, % de descuento o nombre del evento). Uno por banner. |
| hugeTitleM | El titular de apoyo: titular principal cuando el banner tiene imagen fuerte o poco espacio. |
| hugeTitleS | El contenido: banners compactos, formatos verticales o cuando acompaña a otro elemento sin robar el foco. |

## Text styles

Hay **39 text styles** en la librería semantics, todos ligados a las variables de la colección `Typography`. Nombre: `rol/rolPeso`. En código, cada uno tiene su clase en `tokens.css`.

| Text style | Clase CSS | Peso | Mobile |
| --- | --- | --- | --- |
| huge/hugeBold | `.rp-text-huge-bold` | Bold 700 (legado) | 48 / 48 |
| huge/hugeMedium | `.rp-text-huge-medium` | Medium 500 | 48 / 48 |
| huge/hugeRegular | `.rp-text-huge-regular` | Regular 400 | 48 / 48 |
| h1/h1Bold | `.rp-text-h1-bold` | Bold 700 (legado) | 40 / 40 |
| h1/h1Medium | `.rp-text-h1-medium` | Medium 500 | 40 / 40 |
| h1/h1Regular | `.rp-text-h1-regular` | Regular 400 | 40 / 40 |
| h2/h2Bold | `.rp-text-h2-bold` | Bold 700 (legado) | 32 / 40 |
| h2/h2Medium | `.rp-text-h2-medium` | Medium 500 | 32 / 40 |
| h2/h2Regular | `.rp-text-h2-regular` | Regular 400 | 32 / 40 |
| h3/h3Bold | `.rp-text-h3-bold` | Bold 700 (legado) | 26 / 32 |
| h3/h3Medium | `.rp-text-h3-medium` | Medium 500 | 26 / 32 |
| h3/h3Regular | `.rp-text-h3-regular` | Regular 400 | 26 / 32 |
| h4/h4Bold | `.rp-text-h4-bold` | Bold 700 (legado) | 24 / 32 |
| h4/h4Medium | `.rp-text-h4-medium` | Medium 500 | 24 / 32 |
| h4/h4Regular | `.rp-text-h4-regular` | Regular 400 | 24 / 32 |
| headline/headlineBold | `.rp-text-headline-bold` | Bold 700 (legado) | 20 / 24 |
| headline/headlineMedium | `.rp-text-headline-medium` | Medium 500 | 20 / 24 |
| headline/headlineRegular | `.rp-text-headline-regular` | Regular 400 | 20 / 24 |
| subheadline/subheadlineBold | `.rp-text-subheadline-bold` | Bold 700 (legado) | 10 / 24 |
| subheadline/subheadlineMedium | `.rp-text-subheadline-medium` | Medium 500 | 10 / 24 |
| subheadline/subheadlineRegular | `.rp-text-subheadline-regular` | Regular 400 | 10 / 24 |
| body/bodyBold | `.rp-text-body-bold` | Bold 700 (legado) | 16 / 20 |
| body/bodyMedium | `.rp-text-body-medium` | Medium 500 | 16 / 20 |
| body/bodyRegular | `.rp-text-body-regular` | Regular 400 | 16 / 20 |
| caption-1/caption1Bold | `.rp-text-caption-1-bold` | Bold 700 (legado) | 14 / 16 |
| caption-1/caption1Medium | `.rp-text-caption-1-medium` | Medium 500 | 14 / 16 |
| caption-1/caption1Regular | `.rp-text-caption-1-regular` | Regular 400 | 14 / 16 |
| caption-2/caption2Bold | `.rp-text-caption-2-bold` | Bold 700 (legado) | 12 / 16 |
| caption-2/caption2Medium | `.rp-text-caption-2-medium` | Medium 500 | 12 / 16 |
| caption-2/caption2Regular | `.rp-text-caption-2-regular` | Regular 400 | 12 / 16 |
| label/labelBold | `.rp-text-label-bold` | Bold 700 (legado) | 10 / 12 |
| label/labelMedium | `.rp-text-label-medium` | Medium 500 | 10 / 12 |
| label/labelRegular | `.rp-text-label-regular` | Regular 400 | 10 / 12 |
| footnote/footnoteRegular | `.rp-text-footnote-regular` | Regular 400 | 8 / 12 |
| disclaimer/disclaimerRegular | `.rp-text-disclaimer-regular` | Regular 400 | 6 / 8 |
| legal/legalRegular | `.rp-text-legal-regular` | Regular 400 | 4 / 6 |
| Archivo-Black/hugeTitleL | `.rp-text-hugetitlel` | Regular | 46 / 34 |
| Archivo-Black/hugeTitleM | `.rp-text-hugetitlem` | Regular | 40 / 32 |
| Archivo-Black/hugeTitleS | `.rp-text-hugetitles` | Regular | 30 / 26 |

## Variables

Colección `Typography` en semantics: **42 variables** con modos Mobile, Tablet y Desktop. En CSS: `--rp-type-<familia>-<propiedad>-<rol>`, ya resueltas por breakpoint.

| Grupo | Variables | Ejemplo CSS |
| --- | --- | --- |
| PP Object sans/family | title, content | `--rp-font-family-title` |
| PP Object sans/weight | Heavy, Bold, Medium, Regular | `--rp-font-weight-medium` (500) |
| PP Object sans/size | huge, h1–h4, headline, subheadline, body, caption-1, caption-2, label, footnote, disclaimer, legal | `--rp-type-pp-object-sans-size-body` |
| PP Object sans/line-height | los mismos 14 roles | `--rp-type-pp-object-sans-line-height-body` |
| Archivo Black/family · weight | title · Regular | `--rp-font-family-display` |
| Archivo Black/size · line-height | hugeTitleL, hugeTitleM, hugeTitleS | `--rp-type-archivo-black-size-hugetitlel` |

## Revisión pendiente en Figma

Inconsistencias encontradas en semantics. Hasta resolverlas, los valores de esta página siguen las **variables**.

- **subheadline/*** usan `line-height/headline` en vez de `line-height/subheadline`: en Tablet dan 24 en vez de 16.

- **h1/h1Regular** tiene el peso ligado al primitivo `font/weight/Regular`.

- **legal/legalRegular** tiene size y line-height ligados a primitivos.

- En Tablet, `size/h1` (28) y `line-height/h3` (28) son valores fijos sin alias.

- En Tablet, h1 a h4 son más chicos que en Mobile (h1 28 vs 40).

- No hay variables de letter-spacing ni text-case: el 12% de subheadline y el −4% de Archivo Black solo viven en el text style.
