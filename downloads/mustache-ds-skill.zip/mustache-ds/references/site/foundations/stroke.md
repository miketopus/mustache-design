<!-- generado desde foundations/stroke.html · Rappi 8 · 2026-09-29 — no editar a mano -->

# Stroke

El objeto para definir el color, el ancho y el estilo de un borde o divisor.

## Stroke

El objeto para definir el color, el ancho y el estilo de un borde o divisor.

Puede especificar el color, el ancho y el estilo (sólido, discontinuo o punteado) de un trazo. Dichos trazos tienen muchos usos, incluidos los bordes de los componentes y los componentes divisores.

## Properties

**color** — The stroke color.

**style** — Defines the style of the stroke. Valid values:

- **solid** (default) — a solid stroke.

- **dashed** — a dashed stroke.

- **dotted** — a dotted stroke.

## Stroke Scale

El tamaño del borde está en una escala de 0.5px min.

| Token | Thickness |
| --- | --- |
| strokeSmall | 0.5px |
| strokeMedium | 1px |
| strokeLarge | 2px |
