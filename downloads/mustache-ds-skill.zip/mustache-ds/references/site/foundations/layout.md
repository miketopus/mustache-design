<!-- generado desde foundations/layout.html · Rappi 8 · 2026-09-30 — no editar a mano -->

# Layout

> **Fuente: sitio Mustache (contexto).** Si un nombre o valor de este archivo choca con `SKILL.md`, `references/*.md` o `assets/tokens.css`, ganan esos. Avisa de la diferencia.

En Rappi todos los diseños deben tener como principio el uso correcto de los elementos y espacios, para crear consistencia y claridad en la marca.

- **Tabs** Spacing · Grid

## Layout

En Rappi todos los diseños deben tener como principio, el uso correcto de los elementos y espacios; esto con el fin de crear consistencia y claridad en la marca.

Pestañas de esta sección en la fuente: Spacing | Grid.

## Spacing

El espaciado en un diseño, es una parte fundamental en la consistencia y funcionalidad de una pieza; por esta razón en Mustache, para evitar inconsistencias se establecieron algunos parámetros sobre el espaciado y su uso.

Para el caso de los métodos más usados como: Línea base, líneas claves, líneas de relleno y espaciado incremental; estos lineamientos también son aplicables.

Es necesario tener en cuenta que, la función de los métodos de espaciado es no solo ajustar las proporciones de los contenedores y elementos presentes en la interfaz de usuario, sino también otorgar una consistencia visual a la marca.

Recomendaciones de uso según el sistema operativo para los espaciados son:

- En iOS los componentes deben alinearse a una cuadrícula de línea base (cuadrada) de 8px.

- En el caso de Android, tablets o computadoras de escritorio debe ser de 8dp.

### Spacing scale

Las escalas en el espaciado, son indispensables para crear proporciones adecuadas. Por esta razón siempre deben ser aplicadas en componentes individuales, organizando los elementos con distancias cortas que generen relaciones balanceadas y con detalles.

| Token | Spacing |
| --- | --- |
| Spacing - 0 | 0px |
| Spacing - 1 | 2px |
| Spacing - 2 | 4px |
| Spacing - 3 | 8px |
| Spacing - 4 | 12px |
| Spacing - 5 | 16px |
| Spacing - 6 | 20px |
| Spacing - 7 | 24px |
| Spacing - 8 | 28px |
| Spacing - 9 | 32px |
| Spacing - 10 | 36px |
| Spacing - 11 | 40px |
| Spacing - 12 | 44px |
| Spacing - 13 | 48px |
| Spacing - 14 | 52px |
| Spacing - 15 | 56px |
| Spacing - 16 | 60px |

### Margins

Las márgenes, o más conocidas como áreas de seguridad en una pieza, son las propiedades que permiten visualizar de manera clara y sencilla cualquier diseño, haciéndolo más amigable con las personas usuarias.

Al momento de crear márgenes para espaciar y organizar los elementos, se debe tener en cuenta que estas son construidas con base a la cuadrícula y sus propiedades ej.: Una cuadrícula de 8px debe mantener estas mismas proporciones de izquierda a derecha.

Para mantener una consistencia visual, los píxeles mínimos en los costados son de 24px y, de ser necesario según la situación, estos aumentarán sus proporciones de 8px en adelante.

### Padding

El Padding en nuestros diseños, hace referencia al espaciado presente entre algunos elementos entre sí de la interfaz de la app de Rappi. Este método de espaciado, establece la distancia entre cada elemento en incrementos de 8px o de 4px.

El Padding presente entre un objeto y otro puede ser medido tanto vertical como horizontalmente.

### Alignment

Las alineaciones en Rappi, corresponden a la ubicación de los elementos dentro de un componente; su uso correcto en cada diseño, genera una mejor lecturabilidad y jerarquía de los objetos dentro de la interfaz.

## Grid

### Baseline grid

Las cuadrículas base en cada diseño de nuestra app, tienen como finalidad, brindar experiencias más fluidas y claras para nuestras personas usuarias. Su uso en nuestra tipografía, nos garantiza como marca una mayor consistencia visual.

En el caso de los sistemas espaciales, este conjunto de reglas, está creado con el fin de establecer las medidas, espaciados y dimensiones correctas a implementar en nuestra interfaz de usuario.

Las recomendaciones de uso para una cuadrícula son:

- Cada cuadrícula debe utilizar una línea base de 4px.

- Su crecimiento debe ser exponencial en múltiplos de 4px (tanto en iconos como en componentes y dimensiones de cualquier diseño).

- Los objetos dentro de una cuadrícula de 8px deben estar alineados a esta y, de ser necesario, pueden ser múltiplos de 4px.

> **Nota:** las cuadrículas de 4px dan mayor flexibilidad al momento de la creación de los componentes y la organización de la información en la interfaz de usuario.

### 8pt spatial system

Al momento de aplicar la escala espacial, en la interfaz de usuario, esta puede ser en la margen, espacio, altura y ancho de un elemento o sección.

En el siguiente ejemplo, podrás ver la altura de la línea del texto con 16px, el espaciado de 8px y en la parte superior e inferior, en el caso del botón, una altura de 40px.
