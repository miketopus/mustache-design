<!-- generado desde foundations/illustrations-3d.html · Rappi 8 · 2026-10-02 — no editar a mano -->

# Illustrations 3D's

> **Fuente: sitio Mustache (contexto).** Si un nombre o valor de este archivo choca con `SKILL.md`, `references/*.md` o `assets/tokens.css`, ganan esos. Avisa de la diferencia.

Mustache utiliza un estilo de ilustración preciso para ayudar a los usuarios a comprender rápida y claramente cómo funcionan las cosas en cada experiencia.

- **Tabs** Storetypes · Placeholders · Objects · Prime

## Illustrations 3D's

Mustache utiliza un estilo de ilustración preciso para ayudar a los usuarios a comprender rápida y claramente cómo funcionan las cosas en cada experiencia.

Pestañas de esta sección en la fuente: Storetypes | Placeholders | Objects | Prime.

### Storetypes

| Ilustración | Descripción |
| --- | --- |
| Restaurants | Icono de restaurantes. |
| CPG's | Icono de Mercados. |
| Pharmacy | — |
| More Services | — |
| ecommerce | — |

> **Así está en la fuente.** Pharmacy, More Services y ecommerce no tienen descripción de texto en la página original.

## Placeholders

Galería de ilustraciones, solo con nombre debajo de cada glifo (el resto es contenido visual):

mustacheprofilebasketcpgcpg-whimwhimrest-storeshoptoppingsrestrest-dark

## Objects

gift+coinsgift-detachedgift-goldgift-purpleheartheartsopen-gift-goldopen-gift-gold-promoopen-gift-purpleprime-crownpromospromos-notificationstagtag-primetag-prime-confettiturbo-couponturbo-free-moneyturbo-gold-coupon

## Prime

ATMbubble-chatburgercalendarcashbackchronometercoinscommentsconfettigiftlikemotorcycleprime-crownpromosside-motorcycletag
