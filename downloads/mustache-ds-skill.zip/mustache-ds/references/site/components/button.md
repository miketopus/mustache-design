<!-- generado desde components/button.html · Rappi 8 · 2026-10-02 — no editar a mano -->

# Button

> **Fuente: sitio Mustache (contexto).** Si un nombre o valor de este archivo choca con `SKILL.md`, `references/*.md` o `assets/tokens.css`, ganan esos. Avisa de la diferencia.
>
> Fuente: componente `flexible` de Figma (mobile-library Rappi 8). Tamaños menores a `large` (48px) necesitan hit area extendida a 48px.

Dispara la acción que la persona quiere hacer: pedir, pagar, confirmar, agregar. En Figma es el componente `flexible`: 3 estilos, 5 tamaños, 4 estados, y puede llevar ícono a la izquierda, a la derecha o solo ícono.

- **Estado** Live

- **Figma** `flexible` · mobile-library Rappi 8
Abrir en Figma ↗

Vista previa en vivo Figma · mobile-library Rappi 8

Variantes · flexible

Estilo
styleprimary
primarysecondarytertiary

Tamaño
sizemedium
xSmallsmallmediumlargexLarge

Estado
stateenable
enableloadingdisableskeleton

Ícono
left/right Icon · labelsin ícono
sin íconoa la izquierdaa la derechasolo ícono (sin label)

## Estilos

El estilo marca la jerarquía. En una misma vista, que el ojo sepa en un segundo cuál es la acción principal.

### Primary style=primary

La acción principal de la pantalla: pagar, pedir, continuar. **Una por vista.**

### Secondary style=secondary

Acción de apoyo al lado de un primary, o la principal cuando la pantalla no necesita tanto peso.

### Tertiary style=tertiary

La de menor énfasis: cancelar, omitir, acciones opcionales. Borde en vez de fondo.

## Tamaños

Cinco alturas, de 24 a 56px. Elige por el espacio y la importancia, no por el largo del texto.

| size | Alto | Cuándo |
| --- | --- | --- |
| `xSmall` | 24px | Dentro de cards o filas densas, como acción secundaria. |
| `small` | 32px | Acciones en listas, banners y headers. |
| `medium` | 40px | Acciones dentro del contenido. |
| `large` | 48px | CTA principal de una pantalla. |
| `xLarge` | 56px | CTA fijo abajo (checkout, confirmar pedido). |

Por debajo de `large`, el área táctil se extiende a 48px aunque el botón se vea más chico.

## Estados

Skeleton

| state | Qué comunica |
| --- | --- |
| `enable` | Disponible. |
| `loading` | La acción está en curso. El label se reemplaza por 3 puntos y el botón no se puede volver a tocar. |
| `disable` | No disponible todavía. Explica cerca por qué (ej. "Elige un método de pago"). |
| `skeleton` | La pantalla está cargando y el botón aún no existe. No es interactivo. |

## Con ícono

Ícono a la izquierda **o** a la derecha, nunca los dos. Solo ícono cuando la acción se entiende sin texto (agregar, cerrar) y siempre con nombre accesible.

## Implementación con tokens

Cómo se traduce `flexible` a CSS con las variables de `tokens.css` del kit. Es la referencia de valores; el componente de cada plataforma debe cumplirla.

```
.rp-btn {
  display: inline-flex; align-items: center; justify-content: center;
  gap: 8px;                                   /* medium */
  height: 40px; padding: 0 16px;              /* medium */
  border-radius: var(--rp-radius-pill);
  font-family: var(--rp-font-family-content);
  font-weight: var(--rp-font-weight-medium);
  font-size: var(--rp-type-pp-object-sans-size-caption-1);
}
.rp-btn--primary   { background: var(--rp-color-background-accent);   color: var(--rp-color-ink-inverse-on); }
.rp-btn--secondary { background: var(--rp-color-background-weak);     color: var(--rp-color-ink-strong); }
.rp-btn--tertiary  { background: var(--rp-color-background-standard); color: var(--rp-color-ink-strong);
                     border: var(--rp-stroke-standard) solid var(--rp-color-line-border-standard); }

.rp-btn:disabled               { color: var(--rp-color-ink-disabled); }
.rp-btn--primary:disabled      { background: var(--rp-color-background-disabled); }
.rp-btn--skeleton              { background: var(--rp-color-skeleton-standard); color: transparent; pointer-events: none; }

/* Solo web. En User App (mobile) estos tokens son N/A: no se usan. */
.rp-btn--primary:hover    { background: var(--rp-color-interactive-bg-accent-hover); }
.rp-btn--primary:active   { background: var(--rp-color-interactive-bg-accent-pressed); }
.rp-btn--secondary:hover  { background: var(--rp-color-interactive-bg-weak-hover); }
.rp-btn--secondary:active { background: var(--rp-color-interactive-bg-weak-pressed); }
.rp-btn--tertiary:hover   { background: var(--rp-color-interactive-bg-standard-hover); }
.rp-btn--tertiary:active  { background: var(--rp-color-interactive-bg-standard-pressed); }
.rp-btn:focus-visible     { outline: var(--rp-stroke-selected) solid var(--rp-color-interactive-border-focus); outline-offset: 2px; }
```

Tamaños: alto 24 · 32 · 40 · 48 · 56 y padding 8 · 16 · 16 · 24 · 28 (ver Personalización). `xSmall` usa `caption-2`; `large` y `xLarge` usan `body`.

## Accesibilidad

| Tema | Regla |
| --- | --- |
| **Área táctil** | Mínimo 48×48px y 8px entre áreas táctiles. `xSmall` (24px), `small` (32px) y `medium` (40px) necesitan área táctil extendida a 48px aunque se vean más chicos. |
| **Contraste** | `primary` usa `ink/inverse-on` sobre `background/accent`: **2.2:1**, no llega al 4.5:1 de WCAG AA. Es el componente oficial; señálalo en revisiones. `secondary` y `tertiary` (`ink/strong`) sí pasan. |
| **Solo ícono** | Con `label=false` el botón no tiene texto visible: dale nombre accesible (`aria-label`) que diga la acción, no el ícono ("Agregar al carrito", no "Más"). |
| **Loading** | El label se reemplaza por los 3 puntos: anuncia el estado (`aria-busy="true"`) y evita que se dispare dos veces. |
| **Disable** | `ink/disabled` no busca contraste: no comuniques solo con el botón deshabilitado por qué no se puede continuar; explícalo cerca. |
| **Skeleton** | Es un placeholder de carga, no un botón: no debe recibir foco ni clic. |
| **Foco (web)** | Anillo de stroke `selected` (2px) con `interactive/border-focus`. En mobile no aplica. |

## Propiedades en Figma

Componente `flexible` de **mobile-library Rappi 8** (182 variantes). Así se configura una instancia.

| Propiedad | Valores | Default |
| --- | --- | --- |
| `style` | primary · secondary · tertiary | primary |
| `size` | xSmall · small · medium · large · xLarge | xSmall |
| `state` | enable · loading · disable · skeleton | enable |
| `label` | true · false (false = solo ícono) | true |
| `left Icon` | true · false | false |
| `right Icon` | true · false | false |
| `icon type` | Intercambio de instancia (cualquier ícono de la librería) | filled/filled_add |
| `label text` | Texto | "Label" |

### Combinaciones que existen

Ícono a la izquierda **o** a la derecha, nunca los dos. Solo ícono usa `left Icon=true` con `label=false`. **Loading** no existe con ícono + label: solo con label o solo ícono.

### Medidas por tamaño

| size | Alto | Padding lateral | Texto | Ícono · separación |
| --- | --- | --- | --- | --- |
| `xSmall` | 24 | 8 | `caption-2/caption2Medium` | 16 · 4 |
| `small` | 32 | 16 | `caption-1/caption1Medium` | 20 · 4 |
| `medium` | 40 | 16 | `caption-1/caption1Medium` | 24 · 8 |
| `large` | 48 | 24 | `body/bodyMedium` | 24 · 12 |
| `xLarge` | 56 | 28 | `body/bodyMedium` | 24 · 12 |

Solo ícono: cuadrado del alto del tamaño (24 a 56px). Radio: `pill`.

## Tokens

Leídos de las variantes de Figma. Todo en token semántico.

| style · state | Fondo | Texto / ícono | Borde |
| --- | --- | --- | --- |
| primary · enable | `background/accent` | `ink/inverse-on` | — |
| secondary · enable | `background/weak` | `ink/strong` | — |
| tertiary · enable | `background/standard` | `ink/strong` | `line/border-standard` |
| primary · disable | `background/disabled` | `ink/disabled` | — |
| secondary · disable | `background/weak` | `ink/disabled` | — |
| tertiary · disable | `background/standard` | `ink/disabled` | `line/border-standard` |
| * · loading | el de su style | puntos: `ink/inverse-on` (primary) · `ink/strong` (secondary, tertiary) | el de su style |
| * · skeleton | `skeleton/standard` | `skeleton/standard` | — |

Radio `pill` · borde `stroke/standard` (1px) en tertiary.

### Estados de web

Solo en los temas web (RT App, Cargo, Pay, Merchants, Portal Partners…). En los temas mobile, **User App** y **Nitro**, estos tokens valen N/A porque en la app no hay hover ni foco de teclado.

| style | Hover | Pressed |
| --- | --- | --- |
| primary | `interactive/bg-accent-hover` | `interactive/bg-accent-pressed` |
| secondary | `interactive/bg-weak-hover` | `interactive/bg-weak-pressed` |
| tertiary | `interactive/bg-standard-hover` | `interactive/bg-standard-pressed` |
| Foco (todos) | Anillo stroke `selected` (2px) con `interactive/border-focus` |  |
