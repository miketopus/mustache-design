<!-- generado desde components/button.html · Rappi 8 · 2026-09-30 — no editar a mano -->

# Button

> **Fuente: sitio Mustache (contexto).** Si un nombre o valor de este archivo choca con `SKILL.md`, `references/*.md` o `assets/tokens.css`, ganan esos. Avisa de la diferencia.
>
> `disabled` aparece como variante en el paquete, pero en diseño trátalo como **estado**. Tamaños menores a `large` (48px) necesitan hit area extendida a 48px.

Disparador de acción principal en cualquier superficie. Renderiza un `<button>` (o cualquier elemento vía `asChild`) con tokens semánticos de variante y tamaño.

- **Estado** Live

- **Paquete** @rappi/ds-web

- **Extiende** <button>

## Uso

Extiende `<button>`: todos los atributos nativos de HTML, event handlers, props ARIA y atributos `data-*` están soportados junto con las props de abajo.

```
import Button from '@rappi/ds-web/web/atoms/Button';

export function CheckoutCta() {
  return <Button onClick={handle}>Save</Button>;
}
```

```
<Button variant="primary" size="medium" onClick={handle}>Save</Button>
<Button asChild variant="secondary"><a href="/path">Go</a></Button>
```

## Variantes

`variant` define la intención visual y mapea a un rol semántico: **primary** = acción dominante, **secondary** = acción de soporte, **error** = destructiva, **inverse** = sobre superficies oscuras, **disabled** = no disponible. (`neutral` / `outline` existen como alternativas de bajo énfasis, sin story dedicado en la fuente.)

### Primary variant="primary"

<Button variant="primary">Click me</Button>

### Secondary variant="secondary"

<Button variant="secondary">Click me</Button>

### Disabled variant="disabled"

<Button variant="disabled" disabled>Click me</Button>

### Error variant="error"

<Button variant="error">Click me</Button>

### Inverse variant="inverse"

<Button variant="inverse">Click me</Button>

## Tamaños

`size` combina escala de spacing y tipografía. **xsmall** es de tipo tag, **xlarge** es para un CTA hero.

| Token | Alto |
| --- | --- |
| `xsmall` | 24px |
| `small` | 32px |
| `medium` | 40px |
| `large` | 48px |
| `xlarge` | 56px |

## Props

| Prop | Descripción | Default |
| --- | --- | --- |
| `variant` | Intención visual. Mapea a un rol semántico: `primary`, `secondary`, `error`, `inverse`, `disabled`, `neutral`, `outline`. | `'primary'` |
| `size` | Escala de spacing + tipografía: `xsmall`, `small`, `medium`, `large`, `xlarge`. | `'medium'` |
| `asChild` | Cuando es `true`, renderiza vía Radix Slot y fusiona las props sobre el único hijo. Úsalo para aplicar el estilo de Button a un link o elemento custom. | `false` |
| `onClick` | Evento — `function`. | — |
| `children` | Slot — `string`. | — |
| `disabled` | Estado — `boolean`. | — |

> **Fuente.** Descripción, props y variantes replicadas 1:1 desde `Rappi Web DS` (Storybook, Atoms / Button). Los colores usan nuestros propios tokens semánticos (`background.accent`, `background.error`, etc.) en vez de los valores originales del paquete.
