<!-- generado desde patterns/dialogs.html · Rappi 8 · 2026-09-30 — no editar a mano -->

# Dialogs

> **Fuente: sitio Mustache (contexto).** Si un nombre o valor de este archivo choca con `SKILL.md`, `references/*.md` o `assets/tokens.css`, ganan esos. Avisa de la diferencia.

En nuestra interfaz, un diálogo es una “conversación” entre el sistema y las personas usuarias con el fin de solicitar o brindar información.

## Dialogs

En nuestra interfaz, un diálogo es una "conversación" entre el sistema y las personas usuarias con el fin de solicitar o brindar información.

Hay dos tipos de diálogos: modales y no modales; su uso dependerá de aquello que deseamos comunicar.

## Overview

Usar los diálogos en el momento adecuado y de forma clara, nos permite brindar a nuestras personas usuarias información relevante y pertinente. Su aplicación en diferentes escenarios hace del recorrido dentro de nuestra interfaz una experiencia más fluida.

El propósito de un diálogo surge de la acción realizada por la persona usuaria; su principal razón de ser es comunicar de manera clara, sencilla y concisa una información o acción.

### Anatomía de los diálogos

### Mejores prácticas

> **Así está en la fuente.** Los títulos "Anatomía de los diálogos" y "Mejores prácticas" no tienen texto de cuerpo debajo en la página original; probablemente sea solo contenido visual.
