<!-- generado desde patterns/settings.html · Rappi 8 · 2026-10-01 — no editar a mano -->

# Settings

> **Fuente: sitio Mustache (contexto).** Si un nombre o valor de este archivo choca con `SKILL.md`, `references/*.md` o `assets/tokens.css`, ganan esos. Avisa de la diferencia.

Las personas prefieren las aplicaciones que se adaptan cada vez mejor a sus necesidades a través de sus ajustes personalizados.

## Settings

Las personas prefieren las aplicaciones que se adaptan cada vez mejor a sus necesidades a través de sus ajustes personalizados, conoce cómo hacerlo.

## Mejores prácticas

- Ofrece al momento de cada personalización en los ajustes un contexto breve y claro que le permita a las personas usuarias personalizar esas acciones con base a sus necesidades.

- Permítele a las personas usuarias de forma específica y clara hacer los ajustes y personalizaciones en la interfaz que requieran necesarios para tener una mejor experiencia de uso.

- Elige un elemento gráfico que represente claramente esta función de "ajustes".

- Mantén las configuraciones de sistemas globales, pero adaptables a las personas según su ubicación y cultura. Ej: Accesibilidad, Navegación, Métodos de autenticación, lenguaje, etc.

- Haz de la selección de configuraciones como los Inapp algo de fácil selección sin influenciar o interferir en la activación y vista de estos.
