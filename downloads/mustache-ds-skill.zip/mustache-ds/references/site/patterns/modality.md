<!-- generado desde patterns/modality.html · Rappi 8 · 2026-11-05 — no editar a mano -->

# Modality

> **Fuente: sitio Mustache (contexto).** Si un nombre o valor de este archivo choca con `SKILL.md`, `references/*.md` o `assets/tokens.css`, ganan esos. Avisa de la diferencia.

Soluciones gráficas que, a través de un diseño fluido y sencillo, presentan el contenido de una manera clara que facilita la toma de decisiones.

## Modality

Estas soluciones gráficas tienen como fin, a través de su diseño fluido y sencillo, presentar el contenido de una manera clara que facilite la toma de decisiones en las personas usuarias.

iOS: another component of iOS 13's new look is cards. Since the original SDK, the default presentation style in iPhone has covered the full screen. We're changing that default to a much more fluid, card presentation — and even better, they are dismissible with just a single downwards swipe.

New in iOS 13 we have a standard design for presentations. For example, if I'm here in the Contacts app and I tap plus to add a new contact, we have a new presentation style that looks like this, rather than the full screen presentation that we had before. You can see that the root view controller's view is not as scaled down and not removed from the view hierarchy.

> **Componente:** las sábanas y pantallas completas de este patrón se arman con [Modal sheets](../components/modal-sheets.html) (handle-sheets, stacked-sheets, full-screen-sheets y full-screen).

## ¿Cuándo usar un estilo determinado?

Elegir entre todas las opciones que nos da Apple/Android puede ser algo complejo.

En primer lugar, debemos evaluar si realmente necesitamos una vista modal o no.

Una experiencia modal saca a las personas de su contexto actual, por lo que es esencial usar modales solo cuando le brindan un beneficio al usuario.

No deseamos molestar a nuestros usuarios. Pero, cuando decida utilizar un modal, su elección debe basarse en el nivel o la complejidad del compromiso. Use una hoja para contenido modal no inmersivo que no resulte en una tarea compleja.

Utilice una vista modal de pantalla completa para contenido envolvente, como videos, fotos o vistas de cámara, o una tarea compleja que se beneficie de una presentación de pantalla completa, como marcar un documento o editar una foto.

## Tipos de modales

Pueden ocupar toda la pantalla, o una parte de ella. Pueden estar centrados, fijados en la parte superior o inferior. A veces aparecen, a veces se deslizan. No es de extrañar que esto sea confuso.

**Pickers** — Este tipo de modal requiere una decisión antes de poder continuar. Puede ser un cuadro de diálogo de advertencia que le permite especificar qué desea hacer o qué modo desea seleccionar.

**Popover / Hoja de acciones / Innap** — Popover ayuda si el contexto de la pantalla anterior es importante. La hoja de acciones es la mejor para mostrar múltiples acciones: es una opción segura cuando no tiene mucho contenido adicional para mostrar además de la lista. Innap hace un gran trabajo explicando la relación entre puntos de vista; si necesita hacer una pregunta u obtener un permiso del usuario, lo mejor es ir con una alerta. Ninguno de esos ocupa toda la pantalla, porque están destinados a ser rápidos de usar: haces una selección y estás de vuelta.

**Doers** — Esos modales son para realizar tareas. Son excelentes para agregar, editar, básicamente cualquier tarea compleja.

**Pantalla completa** — El tipo más común de modal. Cubre toda la pantalla, lo que requiere toda la atención. Diseñado para tareas complejas que pueden tener múltiples pasos. Para los modales de pantalla completa, generalmente se acepta que la acción principal (Listo / Guardar / Cerrar) siempre está en la esquina superior derecha, y la acción destructiva (Cancelar) debe estar en la esquina superior izquierda.

**Pantalla Parcial** — A veces tiene una función que afecta una parte de la vista principal. En ese caso, es útil mostrarlo en segundo plano, para el contexto: la gente obtendrá instantáneamente lo que hace el modal. Cuando selecciona la vista de la pantalla parcial, hay dos cosas adicionales a tener en cuenta: elige una animación apropiada (si una vista está relacionada con algo en la parte superior de la pantalla, deja que se deslice desde allí) y agrega un gesto cercano (cuando los modales aparecen con una cierta animación, las personas a menudo intentan revertirla con gestos; apoyarlo hará que la aplicación se sienta más natural). A veces la función puede referirse a una parte específica de la vista anterior, lo que significa que también se puede usar un popover ahí.

**Sábanas** — El estilo de presentación de la hoja aparece como una tarjeta que cubre parcialmente el contenido subyacente y atenúa todas las áreas descubiertas para evitar la interacción con ellas. El borde superior de la vista principal o una tarjeta anterior es visible detrás de la tarjeta actual para ayudar a las personas a recordar la tarea que suspendieron cuando abrieron la tarjeta. Las personas descartan una tarjeta deslizando hacia abajo desde la parte superior de la pantalla, deslizando hacia abajo desde cualquier lugar de la pantalla cuando el contenido de la tarjeta se desplaza hacia arriba, o tocando un botón. Use una hoja para contenido modal no inmersivo que no permita una tarea compleja.

**Pantalla Completa** — El estilo de presentación a pantalla completa cubre toda la pantalla. La vista anterior está completamente cubierta, minimizando la distracción visual. Las personas descartan una vista modal de pantalla completa tocando un botón. Use una vista modal de pantalla completa para contenido envolvente, como videos, fotos o vistas de cámara, o una tarea compleja que se beneficie de una presentación de pantalla completa, como marcar un documento o editar una foto.

Los modales son una herramienta muy efectiva. Al principio puede resultarle difícil de conseguir. Pero cuando lo haces bien, tu aplicación se sentirá mucho más rápida y fácil de usar.

> **Así está en la fuente.** La página menciona un diagrama de flujo de referencia rápida para elegir el tipo de modal, pero es solo contenido visual (sin texto extraíble).

## Buenas prácticas

Si al final decide usar una modal, considere y recuerde lo siguiente:

- ¿Puedes decir claramente cuál es el propósito de este modal? Mantenga las tareas modales simples, cortas y enfocadas.

- Las modales siempre deben incluir un botón de descarte. No solo permitirá a los usuarios que no conocen el gesto de descartar el modal, sino que también mejorará la accesibilidad.

- Independientemente de si las personas usan el gesto de deslizar o un botón para cerrar la vista, si la acción puede provocar la pérdida de datos generados por el usuario, presente una hoja de acciones que explique la situación y brinde a las personas formas de resolverla (como "Eliminar borrador" y "Guardar borrador" al descartar un nuevo correo electrónico).

- En general, es recomendable agregar un título a un modal que describa su propósito. A veces es necesario incluir un subtítulo para mayor comprensión.

## Ejemplos de motion

Todos los tiempos en segundos. **Inicio** cuenta desde que arranca la entrada o la salida.

Casi todas las modales comparten la misma base: suben desde abajo en 0,20s mientras el scrim pasa de 0% a 80%. Al cerrar, rebotan 24px hacia arriba y bajan en 0,20s.

### Sábana · Detalle de producto

**Se abre:** al tocar un producto para ver su detalle o elegir sus opciones.

Entrada

| Inicio | Elemento | Movimiento | Duración |
| --- | --- | --- | --- |
| 0s | Modal | Sube desde abajo hasta su posición | 0,20s |
| 0s | Capa negra (scrim) | Opacidad de 0% a 80% | 0,20s |
| 0,10s | Tab bar (stepper y botón agregar) | Entra desde abajo y termina al mismo tiempo que la modal | 0,10s |

Salida

| Inicio | Elemento | Movimiento | Duración |
| --- | --- | --- | --- |
| 0s | Modal | Sube 24px | 0,10s |
| 0,10s | Modal | Baja hasta salir de la pantalla | 0,20s |
| 0s | Capa negra (scrim) | Opacidad de 80% a 0% | 0,20s |
| 0,10s | Tab bar | Baja junto con la modal | 0,20s |

### Pantalla parcial · Más servicios (Home)

**Se abre:** al tocar "Más servicios" en el Home.

Entrada

| Inicio | Elemento | Movimiento | Duración |
| --- | --- | --- | --- |
| 0s | Modal | Sube desde abajo hasta su posición | 0,20s |
| 0s | Capa negra (scrim) | Opacidad de 0% a 80% | 0,20s |

Salida

| Inicio | Elemento | Movimiento | Duración |
| --- | --- | --- | --- |
| 0s | Modal | Sube 24px | 0,10s |
| 0,10s | Modal | Baja hasta salir de la pantalla | 0,20s |
| 0s | Capa negra (scrim) | Opacidad de 80% a 0% | 0,20s |

### Pantalla parcial · Oferta

**Se abre:** sola en el Home, sin que la persona haga nada, para comunicar un deal de forma rápida.

Entrada

| Inicio | Elemento | Movimiento | Duración |
| --- | --- | --- | --- |
| 0s | Modal | Sube desde abajo hasta su posición | 0,20s |
| 0s | Capa negra (scrim) | Opacidad de 0% a 80% | 0,20s |

Salida

| Inicio | Elemento | Movimiento | Duración |
| --- | --- | --- | --- |
| 0s | Modal | Sube 24px | 0,10s |
| 0,10s | Modal | Baja hasta salir de la pantalla | 0,20s |
| 0s | Capa negra (scrim) | Opacidad de 80% a 0% | 0,15s |

### Pantalla parcial · Rescate

**Se abre:** sola en el Home cuando el pedido fue entregado, con opciones de soporte para esa orden.

Entrada

| Inicio | Elemento | Movimiento | Duración |
| --- | --- | --- | --- |
| 0s | Modal | Sube desde abajo hasta su posición | 0,20s |
| 0s | Capa negra (scrim) | Opacidad de 0% a 80% | 0,20s |

Salida

| Inicio | Elemento | Movimiento | Duración |
| --- | --- | --- | --- |
| 0s | Modal | Sube 24px | 0,10s |
| 0,10s | Modal | Baja hasta salir de la pantalla | 0,20s |
| 0s | Capa negra (scrim) | Opacidad de 80% a 0% | 0,15s |

### Pantalla completa · Entrega estimada (ETA)

**Se abre:** al tocar el seguimiento de la orden en el header.

Entrada

| Inicio | Elemento | Movimiento | Duración |
| --- | --- | --- | --- |
| 0s | Pantalla completa | Sube desde abajo hasta su posición | 0,20s |
| 0,30s | Componente con handle | Entra desde abajo (0,10s después de que la pantalla llega) | 0,20s |
| 0,30s | Tiempo de entrega | Entra desde arriba, desplazándose hacia abajo | 0,20s |
| 0,40s | Informational messages | Sube 50px desde detrás del componente con handle | 0,20s |

Salida

| Inicio | Elemento | Movimiento | Duración |
| --- | --- | --- | --- |
| 0s | Pantalla completa | Baja hasta salir de la pantalla | 0,20s |

> **Por confirmar.** Al cerrar, el scrim dura 0,20s en Detalle de producto y Más servicios, pero 0,15s en Oferta y Rescate. Si no es intencional, conviene unificarlo.
