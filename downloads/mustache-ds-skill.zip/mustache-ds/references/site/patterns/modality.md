<!-- generado desde patterns/modality.html · Rappi 8 · 2026-09-28 — no editar a mano -->

# Modality

Soluciones gráficas que, a través de un diseño fluido y sencillo, presentan el contenido de una manera clara que facilita la toma de decisiones.

- **Tabs** Design · Usage

## Modality

Estas soluciones gráficas tienen como fin, a través de su diseño fluido y sencillo, presentar el contenido de una manera clara que facilite la toma de decisiones en las personas usuarias.

Pestañas de esta sección en la fuente: Design | Usage.

## Design

iOS: another component of iOS 13's new look is cards. Since the original SDK, the default presentation style in iPhone has covered the full screen. We're changing that default to a much more fluid, card presentation — and even better, they are dismissible with just a single downwards swipe.

New in iOS 13 we have a standard design for presentations. For example, if I'm here in the Contacts app and I tap plus to add a new contact, we have a new presentation style that looks like this, rather than the full screen presentation that we had before. You can see that the root view controller's view is not as scaled down and not removed from the view hierarchy.

### ¿Cuándo usar un estilo determinado?

Elegir entre todas las opciones que nos da Apple/Android puede ser algo complejo.

En primer lugar, debemos evaluar si realmente necesitamos una vista modal o no.

Una experiencia modal saca a las personas de su contexto actual, por lo que es esencial usar modales solo cuando le brindan un beneficio al usuario.

No deseamos molestar a nuestros usuarios. Pero, cuando decida utilizar un modal, su elección debe basarse en el nivel o la complejidad del compromiso. Use una hoja para contenido modal no inmersivo que no resulte en una tarea compleja.

Utilice una vista modal de pantalla completa para contenido envolvente, como videos, fotos o vistas de cámara, o una tarea compleja que se beneficie de una presentación de pantalla completa, como marcar un documento o editar una foto.

### Buenas prácticas

Si al final decide usar una modal, considere y recuerde lo siguiente:

- ¿Puedes decir claramente cuál es el propósito de este modal? Mantenga las tareas modales simples, cortas y enfocadas.

- Las modales siempre deben incluir un botón de descarte. No solo permitirá a los usuarios que no conocen el gesto de descartar el modal, sino que también mejorará la accesibilidad.

- Independientemente de si las personas usan el gesto de deslizar o un botón para cerrar la vista, si la acción puede provocar la pérdida de datos generados por el usuario, presente una hoja de acciones que explique la situación y brinde a las personas formas de resolverla (como "Eliminar borrador" y "Guardar borrador" al descartar un nuevo correo electrónico).

- En general, es recomendable agregar un título a un modal que describa su propósito. A veces es necesario incluir un subtítulo para mayor comprensión.

### Tipos de Modales

Pueden ocupar toda la pantalla, o una parte de ella. Pueden estar centrados, fijados en la parte superior o inferior. A veces aparecen, a veces se deslizan. No es de extrañar que esto sea confuso.

**Pickers** — Este tipo de modal requiere una decisión antes de poder continuar. Puede ser un cuadro de diálogo de advertencia que le permite especificar qué desea hacer o qué modo desea seleccionar.

**Popover / Hoja de acciones / Innap** — Popover ayuda si el contexto de la pantalla anterior es importante. La hoja de acciones es la mejor para mostrar múltiples acciones: es una opción segura cuando no tiene mucho contenido adicional para mostrar además de la lista. Innap hace un gran trabajo explicando la relación entre puntos de vista; si necesita hacer una pregunta u obtener un permiso del usuario, lo mejor es ir con una alerta. Ninguno de esos ocupa toda la pantalla, porque están destinados a ser rápidos de usar: haces una selección y estás de vuelta.

**Doers** — Esos modales son para realizar tareas. Son excelentes para agregar, editar, básicamente cualquier tarea compleja.

**Pantalla completa** — El tipo más común de modal. Cubre toda la pantalla, lo que requiere toda la atención. Diseñado para tareas complejas que pueden tener múltiples pasos. Para los modales de pantalla completa, generalmente se acepta que la acción principal (Listo / Guardar / Cerrar) siempre está en la esquina superior derecha, y la acción destructiva (Cancelar) debe estar en la esquina superior izquierda.

**Pantalla Parcial** — A veces tiene una función que afecta una parte de la vista principal. En ese caso, es útil mostrarlo en segundo plano, para el contexto: la gente obtendrá instantáneamente lo que hace el modal. Cuando selecciona la vista de la pantalla parcial, hay dos cosas adicionales a tener en cuenta: elige una animación apropiada (si una vista está relacionada con algo en la parte superior de la pantalla, deja que se deslice desde allí) y agrega un gesto cercano (cuando los modales aparecen con una cierta animación, las personas a menudo intentan revertirla con gestos; apoyarlo hará que la aplicación se sienta más natural). A veces la función puede referirse a una parte específica de la vista anterior, lo que significa que también se puede usar un popover ahí.

**Sábanas** — El estilo de presentación de la hoja aparece como una tarjeta que cubre parcialmente el contenido subyacente y atenúa todas las áreas descubiertas para evitar la interacción con ellas. El borde superior de la vista principal o una tarjeta anterior es visible detrás de la tarjeta actual para ayudar a las personas a recordar la tarea que suspendieron cuando abrieron la tarjeta. Las personas descartan una tarjeta deslizando hacia abajo desde la parte superior de la pantalla, deslizando hacia abajo desde cualquier lugar de la pantalla cuando el contenido de la tarjeta se desplaza hacia arriba, o tocando un botón. Use una hoja para contenido modal no inmersivo que no permita una tarea compleja.

**Pantalla Completa** — El estilo de presentación a pantalla completa cubre toda la pantalla. La vista anterior está completamente cubierta, minimizando la distracción visual. Las personas descartan una vista modal de pantalla completa tocando un botón. Use una vista modal de pantalla completa para contenido envolvente, como videos, fotos o vistas de cámara, o una tarea compleja que se beneficie de una presentación de pantalla completa, como marcar un documento o editar una foto.

Los modales son una herramienta muy efectiva. Al principio puede resultarle difícil de conseguir. Pero cuando lo haces bien, tu aplicación se sentirá mucho más rápida y fácil de usar.

> **Así está en la fuente.** La página menciona un diagrama de flujo de referencia rápida para elegir el tipo de modal, pero es solo contenido visual (sin texto extraíble).

## Usage

### Ejemplo Sábana - Detalle de producto

Cuando seleccionamos un elemento para conocer sus detalles o elegir sus características, la modal en la que este se encuentra presente inicia una transición desde la parte inferior hacia la parte superior de la pantalla con una duración de 0,20s.

En el mismo momento en el que la modal, con el elemento mencionado, atraviesa esa transición, una capa de color negro se sobrepone en la pantalla inicial con opacidad de 0% a 80% junto a un fade de 0,20s.

Una vez comienza la animación, a los 0,10s, la modal da paso al Tab bar (con el stepper y botón de agregar) desde la parte inferior de la pantalla con una trayectoria de 0,10 segundos en donde ambos elementos concluyen al mismo tiempo su recorrido.

Al cerrarse la modal, esta se convierte en una animación que asciende 24px en 0,10s, posterior a ello desciende hasta el final de la pantalla con una duración de 0,20s.

Es necesario tener presente que, al mismo momento en que la animación de la modal desciende para finalizar su recorrido en la pantalla, en un trayecto de 0,20s, la Tab bar experimenta la misma transición. Así mismo, en el momento en que la modal asciende, el fade de color negro que se encuentra detrás experimenta una opacidad de 80% a 0% con una duración de 0,20s.

### Ejemplo pantalla parcial - Modal más servicios Home

En el momento en el que se selecciona el botón "Más servicios" en el Home de la app, la modal que ingresa desde la parte inferior de la pantalla hace un recorrido hacia la parte superior de la pantalla con una duración total de 0,20s. Al mismo momento en el que el movimiento sucede, una capa negra se ubica sobre la pantalla con una opacidad de 0% a 80% con 0,20s de duración total.

Al cerrarse la modal, esta se transforma en una animación que asciende 24px con 0,10s de duración, en donde posteriormente la modal vuelve a descender hasta finalizar su interacción en la pantalla con una duración total de 0,20s.

Es necesario tener en cuenta que al momento en que la modal asciende, el fade de la capa negra detrás de esta experimenta una opacidad de 80% a 0% con una duración total de 0,20s.

### Ejemplo pantalla parcial - Oferta

La modal promocional, que surge en la pantalla del Home sin que el usuario realice alguna acción previa, ocurre cuando buscamos comunicar algún deal o contenido de forma rápida y clara. Esta modal surge de la parte inferior de la pantalla hacia la parte superior y ejecuta un recorrido con una duración de 0,20s hasta su final.

A este tipo de modal, en el momento en el que hace su aparición en pantalla, una capa negra se le sobrepone dándole una opacidad de 0% a 80% con una duración de 0,20s.

Al cerrarse la modal, esta se transforma en una animación que asciende 24px con 0,10s de duración, en donde posteriormente la modal vuelve a descender para finalizar su interacción en la pantalla con una duración total de 0,20s.

Es necesario tener en cuenta que al momento en que la modal asciende, el fade de la capa negra detrás de esta experimenta una opacidad de 80% a 0% con una duración total de 0,15s.

### Ejemplo pantalla parcial - Modal Pantalla de rescate

La modal de rescate, que surge en la pantalla del Home sin que el usuario realice alguna acción previa, ocurre cuando buscamos comunicar al usuario que su pedido fue entregado y damos opciones para tener soporte sobre esta orden. Esta modal surge de la parte inferior de la pantalla hacia la parte superior y ejecuta un recorrido con una duración de 0,20s hasta su final.

A este tipo de modal, en el momento en el que hace su aparición en pantalla, una capa negra se le sobrepone dándole una opacidad de 0% a 80% con una duración de 0,20s.

Al cerrarse la modal, esta se transforma en una animación que asciende 24px con 0,10s de duración, en donde posteriormente la modal vuelve a descender hasta finalizar su interacción en la pantalla con una duración total de 0,20s.

Es necesario tener en cuenta que al momento en que la modal asciende, el fade de la capa negra detrás de esta experimenta una opacidad de 80% a 0% con una duración total de 0,15s.

### Ejemplo pantalla completa - Modal entrega estimada

Al seleccionar el componente del seguimiento de la orden en el header, comienza la entrada de la pantalla del ETA. Esta pantalla completa surge de la parte inferior de la pantalla hacia la parte superior y ejecuta un recorrido con una duración de 0,20s hasta su final.

0,10s después de que la pantalla llega a su posición final, se incorpora a la visualización de esta un componente de Handle desde la parte inferior, con una duración total de 0,20s.

Al mismo tiempo, desde la parte superior de la pantalla, entra el componente del Tiempo de Entrega con una duración total de 0,20s con un desplazamiento hacia abajo.

0,20s después de que la pantalla completa entra a su posición final, entra el componente de informational messages. Este componente asciende desde la parte de atrás del componente con Handle, realizando un desplazamiento de 50px hacia arriba con una duración total de 0,20s.

Al cerrarse esta pantalla del ETA, esta desciende hasta finalizar su recorrido en la parte inferior de la pantalla con un tiempo total de 0,20s.
