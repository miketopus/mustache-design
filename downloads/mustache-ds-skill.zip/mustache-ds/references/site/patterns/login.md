<!-- generado desde patterns/login.html · Rappi 8 · 2026-09-30 — no editar a mano -->

# Login

> **Fuente: sitio Mustache (contexto).** Si un nombre o valor de este archivo choca con `SKILL.md`, `references/*.md` o `assets/tokens.css`, ganan esos. Avisa de la diferencia.

El inicio de sesión en un sistema es la acción que permite a las personas usuarias tener acceso a una app o programa.

## Login

El inicio de sesión en un sistema es la acción que permite a las personas usuarias, a través de un nombre de usuario y contraseña, tener acceso a una app o programa.

## Overview

El momento de registro en nuestra app o sistema es la primera interacción con nuestras personas usuarias; por esta razón es necesario crear una experiencia acorde a la etapa a través de nuestro tono de marca.

> **Así está en la fuente.** La página fuente es corta: solo tiene la introducción y este párrafo bajo "Overview".
