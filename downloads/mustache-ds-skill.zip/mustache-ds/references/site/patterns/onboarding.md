<!-- generado desde patterns/onboarding.html · Rappi 8 · 2026-09-28 — no editar a mano -->

# Onboarding

Brindarle a nuestras personas usuarias una primera experiencia sencilla, rápida e intuitiva en nuestra app nos acercará a cautivarlos.

## Onboarding

Brindarle a nuestras personas usuarias una primera experiencia sencilla, rápida e intuitiva en nuestra app nos acercará a cautivarlos.

## Mejores prácticas

Para brindar esta primera gran experiencia en nuestra app, es ideal tener en cuenta estas acciones a través de los contenidos y elementos implementados:

- Crea una experiencia disfrutable que no requiera que las personas deban recordar pasos o información que le solicitarás después.

- Guía y ayuda a través de los elementos y el contenido ideal a las nuevas personas usuarias con el fin de lograr su propósito en el app de una forma sencilla y entretenida.

- Enseña a través de elementos interactivos y un buen storytelling cómo la persona usuaria puede lograr sus objetivos en nuestra app, ya sea desde pedir su hamburguesa favorita, hasta su mercado del mes.

- Integra elementos visuales que guíen el proceso y gestionen paso a paso el recorrido del usuario en el app.
