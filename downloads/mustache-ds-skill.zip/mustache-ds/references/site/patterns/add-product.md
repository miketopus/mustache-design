<!-- generado desde patterns/add-product.html · Rappi 8 · 2026-10-02 — no editar a mano -->

# Add Product

> **Fuente: sitio Mustache (contexto).** Si un nombre o valor de este archivo choca con `SKILL.md`, `references/*.md` o `assets/tokens.css`, ganan esos. Avisa de la diferencia.

Agregar los productos a la canasta en Rappi, al igual que como se hace en la vida real, es una de las experiencias que nos hace diferentes e innovadores.

## Add Product

Agregar los productos a la canasta en Rappi, al igual que como se hace en la vida real, es una de las experiencias que nos hace diferentes e innovadores.

## Agregar producto con stepper - Shop

Al momento de agregar un producto a la canasta, los elementos visuales dentro de la card del producto viven una transición visual. Por esto, es necesario tener claro que al momento de dar tap en el signo (+) en la esquina superior derecha, el stepper modificará su tamaño de derecha a izquierda.

Esta modificación en su tamaño sucede en una escala de 0% a 120% (0s - 0,20s) y de 120% a 100% (0,20s - 0,35s); su duración total es de 0,35s logrando así el efecto perfecto en la acción.

Ten en cuenta que, al mismo tiempo que el stepper cambia su visualización, sobre la imagen del producto se colocará una capa blanca con opacidad de 0% a 80% y un fade de duración de 0,35s.

Recuerda, las transiciones mencionadas anteriormente cambian el estado de la canasta. Si deseas conocer más sobre esta interacción visita la sección de Estados de canasta.

## Agregar un producto desde su modal de detalle - Shop

Cuando agregamos un producto desde su modal de detalle, con el stepper del signo (+) ubicado en la parte inferior izquierda, suceden cambios en simultánea: el contador de unidades aumenta, el color del icono (-) cambia a negro y el monto que se visualiza en el botón de "Agregar" se modifica proporcionalmente.

Al momento en que se selecciona el botón "Agregar", la modal desciende, y sobre el signo de (+) sobre el producto agregado, aparece el contador de unidades que entra con una expansión de 0% a 120% (0s - 0,20s) - 120% a 100% (0,20s - 0,35s).

Recuerda que al aplicarse los cambios mencionados, la canasta cambia de estado. Para conocer más sobre estos, visita la sección Estados de canasta.

## Agregar un producto desde su modal de detalle en Restaurantes

En el caso de la vertical de Restaurantes, al momento de agregar un producto desde su modal de detalle, este puede presentar ciertas variaciones como lo es en el caso de los toppings "obligatorios", los cuales, hasta no ser seleccionados y agregados, no permitirán al botón de "Agregar" cambiar su color a verde y así ser accionable para continuar.

Una vez el botón "Agregar" haya sufrido la modificación para ser accionado, la modal descenderá y el título del producto, que se encontraba alineado con el resto de los contenidos, se desplazará 22px a la derecha para dar paso al contador.

En el caso de la animación del contador, esta sufrirá una expansión del 0% a 120% (0s - 0,20s) y de 120% a 100% (0,20s - 0,35s). Simultáneamente, aparece el botón de la canasta de abajo hacia arriba con una duración de 0,45s.

## Estados de canasta

### Transición de canasta vacía al agregar 1 producto

En el momento en que se agrega el primer producto a la Canasta, el ícono sufre un cambio de color blanco a verde; esta expansión y transición visual se da en una escala de 0% a 120% (0s - 0,20s) y de 120% a 100% (0,20s - 0,35s).

En el instante en que la canasta cambia su color a verde, ocurren 3 rotaciones:

- La primera de 0º a -9º (0s - 0,10s)

- La segunda de -9º a 9º (0,10s - 0,20s)

- La tercera de 9º a 0º (0,20s - 0,30s)

Al finalizar estas 3 rotaciones la canasta pasa a un estado de reposo por 0,20s con escala de 100% para luego tener otra serie de rotaciones:

- La primera de 0º a -9º (0,5s - 1s)

- La segunda de -9º a 9º (1s - 1,10s)

- La tercera de 9º a 0º (1,1s - 1,2s)

Para una duración total de la animación de 1,2s.

### Transición de la canasta al tener 1 elemento o más

En el momento en el que la canasta ya cuenta con un elemento dentro de esta y se le agrega otro(s), esta experimenta 3 rotaciones:

- La primera de 0º a -9º (0s - 0,10s)

- La segunda -9º a 9º (0,10s - 0,20s)

- La tercera de 9º a 0º (0,20s - 0,30s)

Concluyendo una duración total de 0,3s.
