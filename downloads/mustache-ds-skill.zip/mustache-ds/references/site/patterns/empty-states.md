<!-- generado desde patterns/empty-states.html · Rappi 8 · 2026-10-02 — no editar a mano -->

# Empty states

> **Fuente: sitio Mustache (contexto).** Si un nombre o valor de este archivo choca con `SKILL.md`, `references/*.md` o `assets/tokens.css`, ganan esos. Avisa de la diferencia.

Pantallas en nuestra interfaz o sistema que no contienen información, o que informan sobre alguna falla o error.

## Empty states

Los "Empty states" o más conocidos en español como "Espacios vacíos", son aquellas pantallas en nuestra interfaz o sistema que no contienen información o informan sobre alguna falla o error.

> **Así está en la fuente.** La página fuente es muy corta: solo tiene este párrafo introductorio, sin más contenido de cuerpo.
