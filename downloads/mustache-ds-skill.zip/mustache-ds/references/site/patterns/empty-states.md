<!-- generado desde patterns/empty-states.html · Rappi 8 · 2026-09-29 — no editar a mano -->

# Empty states

Pantallas en nuestra interfaz o sistema que no contienen información, o que informan sobre alguna falla o error.

## Empty states

Los "Empty states" o más conocidos en español como "Espacios vacíos", son aquellas pantallas en nuestra interfaz o sistema que no contienen información o informan sobre alguna falla o error.

> **Así está en la fuente.** La página fuente es muy corta: solo tiene este párrafo introductorio, sin más contenido de cuerpo.
