<!-- generado desde patterns/pull-and-refresh.html · Rappi 8 · 2026-09-28 — no editar a mano -->

# Pull and refresh

Página sin contenido en la fuente original.

## Pull and refresh

> **Así está en la fuente.** Página completamente vacía en la fuente: solo el título y el enlace de feedback del sitio, sin párrafos, subtítulos ni imágenes.
