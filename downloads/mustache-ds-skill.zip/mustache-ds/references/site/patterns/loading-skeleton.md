<!-- generado desde patterns/loading-skeleton.html · Rappi 8 · 2026-09-28 — no editar a mano -->

# Loading / Skeleton

Elementos visuales que comunican a las personas usuarias la continuidad de un proceso en la interfaz o sistema.

## Loading / Skeleton

Los patrones de carga, o animaciones de espera, son elementos visuales que comunican a las personas usuarias la continuidad de un proceso en la interfaz o sistema.

## Overview

Al aplicar las animaciones de carga en nuestra interfaz, podemos asegurarnos que nuestras personas usuarias podrán tener la tranquilidad de entender el proceso o tiempo de carga que está tomando su actividad en la app.

Nielsen Norman Group asegura en su artículo Progress Indicators Make a Slow System Less Insufferable que una correcta aplicación de estos procesos crea una experiencia en nuestra interfaz mucho más amigable.

A continuación encontrarás los diseños más usados en los estados de carga en nuestra interfaz y sus recomendaciones de uso:

- **Animaciones tipo loop** — Recomendado para cargas rápidas o transiciones en el sistema; es conocido por su estilo circular y sencillo.

- **Barras de progreso** — Este tipo de diseño permite comunicarle de manera clara a nuestros usuarios que el sistema necesita unos segundos más para cargar su información o acción.

## Skeleton states

Los estados de esqueleto son la manera simplificada y consistente de mostrar en nuestra interfaz que una acción o información se encuentra cargando.

La función y el uso correcto de los estados de esqueleto simplifica y comunica la información o acción que se está llevando a cabo de forma dinámica en la interfaz.

El uso principal de este estado es en:

- Componentes

- Algunas tablas o tarjetas de datos

- Contenedores (mosaicos)

- Listas estructuradas

En algunos componentes accionables como botones, casillas de relleno o campos dinámicos su aplicación no es del todo necesaria. De igual manera, es importante evitar su uso en modales como notificaciones, menús, etc.

La animación de carga del skeleton se visualiza a través de un reflejo blanco que se desplaza de derecha a izquierda, en un ángulo de 2º con una duración de 0,30s. Esta animación se repite con un intervalo de 1 segundo de duración, hasta que el contenido que se va a mostrar esté listo para ser mostrado.

Una vez el contenido que se presenta donde estaba el skeleton esté cargado, este aparece con una animación de desvanecimiento con un cambio de opacidad de 0% a 100% y una duración total de 0,25 segundos.
