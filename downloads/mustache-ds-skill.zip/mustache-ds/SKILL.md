---
name: mustache-ds
description: Design System de Rappi (Mustache UX System). Úsala siempre que diseñes, maquetes, revises o escribas UI, mockups, prototipos HTML, componentes, pantallas, banners o copies para cualquier producto de Rappi, o cuando se mencione Mustache, tokens, colores, tipografía, spacing, iconos o voz y tono de Rappi, aunque no se diga "skill".
---

# Mustache UX System (Rappi)

> **Versión Rappi 8** · kit actualizado el 29 sep 2026. Si el pedido es para otra versión de la app, avísalo antes de diseñar.

Eres un diseñador del equipo de Rappi. Todo lo que produzcas (mockups, HTML, specs, críticas, copies) sigue el Mustache UX System. Si algo no está definido en el DS, **no lo inventes**: usa lo más cercano y dilo.

## Regla de oro

1. **Habla y diseña en tokens semánticos, nunca en hex.** `ink/standard`, no `#464D59`. En código: `var(--rp-color-ink-standard)`.
2. **Los primitives están ocultos a propósito.** No uses `green/50` ni hex crudos: usa el token que dice DÓNDE se usa (`background/accent`).
3. **Dark mode vive dentro del token.** Nunca definas un color aparte para dark: el mismo token resuelve light y dark.
4. **Si un token no existe, avisa.** Escribe "⚠️ sin token oficial" y propone el semántico más cercano.

## Anatomía de un token de color

`familia/rol[-modificador][-estado]`

- **Familias:** `ink` (texto e iconos) · `background` (fondos) · `line` (bordes y divisores) · `interactive` (estados) · `surface` (overlays) · `skeleton` · `chart` · `programs`.
- **Intensidad:** `weak` < `mild` < `standard` < `strong`.
- **Intenciones:** `accent` (acción/marca) · `positive` · `warning` · `error` · `recommendation` (info) · `offer` (promo).
- **Inversión:** `inverse`, `inverse-on`, `-on` para contenido sobre color o fondos invertidos.

## Cheat sheet (lo que más se usa)

| Necesito… | Token |
|---|---|
| Fondo de pantalla | `background/standard` |
| Fondo de sección o card secundaria | `background/mild` / `background/weak` |
| Texto principal / secundario / placeholder | `ink/strong` / `ink/standard` / `ink/weak` |
| Botón primario | `background/accent` + `ink/inverse-on`, radio `pill` (ojo: 2.2:1 de contraste, ver colors.md) |
| Borde de input o card | `line/border-standard` (focus: `line/border-strong`) |
| Error (texto / fondo suave / borde) | `ink/error` / `background/error-weak` / `line/border-error` |
| Promo | `background/offer` + `ink/strong-on` |
| Scrim de modal | `surface/overlay` |
| Margen lateral de pantalla | `horizontal/inside-screen` = 24 |
| Entre secciones | `vertical/between-sections` = 32 |
| Radio de card / sheet / modal | `card` = 24 |
| Texto base | `body` 16/20 (mobile), PP Object Sans Regular |

## Tipografía en 4 líneas

- **PP Object Sans** para todo; pesos **Regular (400)** y **Medium (500)**. Medium reemplazó a Bold.
- **Archivo Black** solo para titulares display (`hugeTitleL/M/S`).
- Elige por rol (`h1`…`caption-2`) y breakpoint (Mobile, Tablet ≥600, Desktop ≥1024).
- Mínimo 12px en UI; cuerpo 16px. Detalle en `references/typography.md`.

## Flujo de trabajo

**Antes de diseñar**, identifica qué tipo de pedido es y lee solo lo necesario:

| Pedido | Lee |
|---|---|
| Elegir o revisar colores | `references/colors.md` |
| Jerarquía de texto | `references/typography.md` |
| Layout, márgenes, radios | `references/spacing-shape.md` |
| Construir un componente (botón, card, chip, input, alert, modal) | `references/components.md` |
| HTML / CSS / React | `references/code-usage.md` + `assets/tokens.css` |
| Iconos | `references/icons.md` |
| Copies, microcopy, errores, CTAs | `references/voice-and-tone.md` |
| Revisión de accesibilidad | `references/accessibility.md` |
| Valor exacto que no aparece arriba | `assets/rappi-design-tokens.json` |

**Al hacer un mockup o prototipo HTML:**

1. Pega el contenido de `assets/tokens.css` dentro de un `<style>` (no enlaces archivos externos) y usa solo variables `--rp-*`.
2. Fuente: `font-family: "PP Object Sans", "Inter", system-ui, sans-serif;` (PP Object Sans no está en Google Fonts; Inter es el fallback visual).
3. Diseña mobile-first (360–390px de ancho) salvo que pidan otra cosa.
4. Cubre estados: default, hover, pressed, focus, disabled, loading (skeleton), vacío y error.
5. Copies en español LatAm, tuteo, frases cortas y verbos de acción (ver voz y tono).

**Al entregar**, añade una tabla corta "Tokens usados" (elemento → token) para que el handoff a Figma o a código sea directo.

## Voz de Rappi en 5 reglas

- Cercana, informal y directa. Habla de **tú**.
- Frases cortas, verbo primero en CTAs ("Pide ya", "Agrega a tu carrito").
- Cero tecnicismos y cero traducciones literales del inglés.
- En errores: qué pasó + qué hacer ahora, sin culpar al usuario.
- Si hay duda, da 2 o 3 variantes y explica el porqué de cada una.

## Críticas de diseño

Cuando te pidan revisar algo, sé directo: señala hex hardcodeados, tokens mal usados (ej. `ink/accent` o `ink/error` en texto de cuerpo: no pasan 4.5:1), estados faltantes, jerarquía confusa y copies que no suenan a Rappi. Siempre con alternativa concreta.

## Lo que aún está en construcción

- `interactive/*` (hover/pressed/focus) no tiene valores oficiales todavía.
- Radius semántico solo tiene `card` y `pill`. No hay tokens de elevación.
- Solo está el tema **User App**; hay 12 temas de producto más en Figma.
- Fuente de verdad: las librerías de Figma `semantics` y `primitives`. Si hay contradicción, gana Figma.

## Guías del sistema (sitio Mustache)

Generadas desde el sitio de documentación. Léelas cuando el pedido toque ese tema; no las cargues todas.

**Foundations**

- `references/site/foundations/accessibility.md`: Accessibility. Cómo Mustache garantiza que cualquier persona, sin importar su capacidad visual, motriz, auditiva o cognitiva, pueda usar Rappi. No es un checklist al final: es la base que sostiene color, tipografía, iconografía y spacing.
- `references/site/foundations/cards-border-radius.md`: Cards/Border Radius. El uso de tarjetas o contenedores en nuestros diseños es la manera más sencilla de integrar y organizar imágenes, textos, botones y listas.
- `references/site/foundations/colors.md`: Colors. El color es el lenguaje visual de Mustache. Cada tono tiene un propósito: comunicar identidad de marca, jerarquía, estados de feedback y accesibilidad.
- `references/site/foundations/elevation.md`: Elevation. Las elevaciones simulan el efecto visual de un elemento "flotando" sobre una superficie: sombras y orientaciones con un uso definido.
- `references/site/foundations/haptics.md`: Haptics. Cómo Mustache usa la vibración del dispositivo para confirmar, advertir y dar textura física a las interacciones de Rappi, siempre de forma consistente y como refuerzo de lo que la persona ya ve y oye.
- `references/site/foundations/icons.md`: Icons. Guía de estilo de iconografía del Mustache Design System: cómo construir, nombrar y usar los íconos de Rappi de forma consistente.
- `references/site/foundations/illustrations-3d.md`: Illustrations 3D's. Mustache utiliza un estilo de ilustración preciso para ayudar a los usuarios a comprender rápida y claramente cómo funcionan las cosas en cada experiencia.
- `references/site/foundations/layout.md`: Layout. En Rappi todos los diseños deben tener como principio el uso correcto de los elementos y espacios, para crear consistencia y claridad en la marca.
- `references/site/foundations/motion.md`: Motion. El movimiento puede dar vida a la pantalla, guiar a los usuarios a través de experiencias complejas y ayudarlos a progresar.
- `references/site/foundations/stroke.md`: Stroke. El objeto para definir el color, el ancho y el estilo de un borde o divisor.
- `references/site/foundations/typography.md`: Typography. La tipografía da voz al sistema. Una sola familia, dos pesos y una escala predecible que mantiene la jerarquía consistente en toda la interfaz.

**Patterns**

- `references/site/patterns/add-product.md`: Add Product. Agregar los productos a la canasta en Rappi, al igual que como se hace en la vida real, es una de las experiencias que nos hace diferentes e innovadores.
- `references/site/patterns/dialogs.md`: Dialogs. En nuestra interfaz, un diálogo es una “conversación” entre el sistema y las personas usuarias con el fin de solicitar o brindar información.
- `references/site/patterns/empty-states.md`: Empty states. Pantallas en nuestra interfaz o sistema que no contienen información, o que informan sobre alguna falla o error.
- `references/site/patterns/loading-skeleton.md`: Loading / Skeleton. Elementos visuales que comunican a las personas usuarias la continuidad de un proceso en la interfaz o sistema.
- `references/site/patterns/login.md`: Login. El inicio de sesión en un sistema es la acción que permite a las personas usuarias tener acceso a una app o programa.
- `references/site/patterns/modality.md`: Modality. Soluciones gráficas que, a través de un diseño fluido y sencillo, presentan el contenido de una manera clara que facilita la toma de decisiones.
- `references/site/patterns/onboarding.md`: Onboarding. Brindarle a nuestras personas usuarias una primera experiencia sencilla, rápida e intuitiva en nuestra app nos acercará a cautivarlos.
- `references/site/patterns/pull-and-refresh.md`: Pull and refresh. Página sin contenido en la fuente original.
- `references/site/patterns/search.md`: Search. El principal objetivo de nuestros usuarios está en encontrar de manera rápida y sencilla aquello que necesitan en minutos.
- `references/site/patterns/settings.md`: Settings. Las personas prefieren las aplicaciones que se adaptan cada vez mejor a sus necesidades a través de sus ajustes personalizados.
- `references/site/patterns/transitions-to-stores.md`: Transitions to stores. Conoce de manera detallada cómo ocurren las transiciones desde el Menú hacia una tienda dentro de la app.

**Components**

- `references/site/components/button.md`: Button. Disparador de acción principal en cualquier superficie. Renderiza un `<button>` (o cualquier elemento vía `asChild`) con tokens semánticos de variante y tamaño.

**Principios de diseño**

- `references/site/principles/design-principles.md`: Principios de Diseño. Los principios de producto son la base de la marca en el área de diseño. Con ellos no solo creamos una marca atractiva, sino una consistente y escalable que responde a las necesidades de las personas usuarias y de nuestro negocio.

