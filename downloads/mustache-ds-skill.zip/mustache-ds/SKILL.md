---
name: mustache-ds
description: Design System de Rappi (Mustache UX System). Úsala siempre que diseñes, maquetes, revises o escribas UI, mockups, prototipos HTML, componentes, pantallas, banners o copies para cualquier producto de Rappi, o cuando se mencione Mustache, tokens, colores, tipografía, spacing, iconos, elevación o voz y tono de Rappi, aunque no se diga "skill". Para documentar un componente desde Figma usa `rappi-component-docs`; para escribir documentación del DS usa `rappi-design-docs`.
---

# Mustache UX System (Rappi)

> **Skill v1.1 · Rappi 8 · 2 oct 2026.** Tema User App (light + dark). Si el pedido es para otra versión de la app u otro tema de producto, avísalo antes de diseñar.

Eres un diseñador del equipo de Rappi. Todo lo que produzcas (mockups, HTML, specs, críticas, copies) sigue el Mustache UX System. Si algo no está definido en el DS, **no lo inventes**: usa lo más cercano y dilo.

## Regla de oro

1. **Habla y diseña en tokens semánticos, nunca en hex.** `ink/standard`, no `#464D59`. En código: `var(--rp-color-ink-standard)`.
2. **Los primitives están ocultos a propósito.** No uses `green/50` ni hex crudos: usa el token que dice DÓNDE se usa (`background/accent`).
3. **Dark mode vive dentro del token.** Nunca definas un color aparte para dark: el mismo token resuelve light y dark.
4. **Si un token no existe, avisa.** Escribe "⚠️ sin token oficial" y propone el semántico más cercano. Nunca uses un token que no esté en `assets/tokens.css`.

## Precedencia (si dos fuentes se contradicen)

1. **Figma** (`semantics` y `primitives`): fuente de verdad. Si tienes el MCP de Figma, gana.
2. **`assets/tokens.css` y `assets/rappi-design-tokens.json`**: exportados de Figma. Definen qué tokens existen.
3. **Este SKILL.md y `references/*.md`**: reglas de uso curadas.
4. **`references/site/**`**: documentación del sitio. Úsala para contexto, patrones y do/don't. Si un nombre o valor choca con 1 a 3, **gana 1 a 3** y avisa de la diferencia.

## Anatomía de un token de color

`familia/rol[-modificador][-estado]`

- **Familias:** `ink` (texto e iconos) · `background` (fondos) · `line` (bordes y divisores) · `interactive` (estados) · `surface` (overlays) · `skeleton` · `chart` · `programs`.
- **Intensidad:** `weak` < `mild` < `standard` < `strong`.
- **Intenciones:** `accent` (acción/marca) · `positive` · `warning` · `error` · `recommendation` (info) · `offer` (promo).
- **Inversión:** `inverse` cambia con el modo. `-on` (`ink/inverse-on`, `ink/strong-on`) es **fijo** en light y dark: úsalo siempre sobre fondos de color.

## Cheat sheet (lo que más se usa)

| Necesito… | Token |
|---|---|
| Fondo de pantalla | `background/standard` |
| Fondo de sección o card secundaria | `background/mild` / `background/weak` |
| Card sobre otra superficie | `background/on-top` |
| Texto principal / secundario / placeholder | `ink/strong` / `ink/standard` / `ink/weak` |
| Botón primario | `background/accent` + `ink/inverse-on`, radio `pill`. ⚠️ 2.2:1, ver "Accesibilidad" |
| Borde de input o card | `line/border-standard` · focus: `line/border-strong` |
| Error (texto / fondo suave / borde) | `ink/error` / `background/error-weak` / `line/border-error` |
| Alerta o banner de feedback | `background/<intención>-weak` + texto `ink/strong` + ícono `ink/<intención>` |
| Promo | `background/offer` + `ink/strong-on` (nunca `ink/strong`: en dark queda blanco sobre amarillo) |
| Scrim de modal | `surface/overlay` |
| Margen lateral de pantalla | `horizontal/inside-screen` = 24 |
| Entre secciones | `vertical/between-sections` = 32 |
| Radio de card / sheet / modal | `card` = 24 · botones y chips: `pill` |
| Borde / selección | stroke `standard` = 1 · `selected` = 2 |
| Texto base | `body` 16/20 (mobile), PP Object Sans Regular |
| Área táctil mínima | **48×48px** y 8px entre áreas táctiles, aunque el elemento se vea más chico |

## Tipografía en 5 líneas

- **PP Object Sans** para UI. Pesos en uso: **Regular (400)** y **Medium (500)**. Medium reemplazó a Bold: los estilos `*Bold` siguen en Figma por legado, no los uses en diseño nuevo.
- **Archivo Black es exclusiva del componente `banner-bigFont`** (mobile-library Rappi 8): solo para su cifra o titular protagonista (ej. el % OFF), con `hugeTitleL/M/S` y tracking −4%. **No es una fuente display general:** en cualquier otro banner, pantalla o pieza usa PP Object Sans (`huge`, `h1`).
- **Text styles** en Figma: `rol/rolPeso` (ej. `body/bodyRegular`, `h2/h2Medium`). Roles: `huge`, `h1`–`h4`, `headline`, `subheadline`, `body`, `caption-1`, `caption-2`, `label`. `subheadline` es un eyebrow: 10px, MAYÚSCULAS, tracking 12%.
- Tamaño y line-height cambian por breakpoint (Mobile, Tablet ≥600, Desktop ≥1024) vía variables de la colección `Typography`.
- Mínimo 12px en UI; cuerpo 16px. `footnote` (8), `disclaimer` (6) y `legal` (4) no van en pantalla. Escala completa y CSS en `references/typography.md`.

## Iconos en 4 líneas

- Librería Figma `icons` (file `kYsnknQmkgVfiawkU6baZb`). Nombres en inglés, minúscula y guion, por lo que se ve (`house`, no `home`).
- **Outline** por defecto; **Filled** solo para activo/seleccionado. No mezcles en un mismo conjunto.
- Tamaños: 16 (denso), **24 (base)**, 32 (empty states, onboarding). Color con `ink/*`.
- Ícono funcional siempre con label accesible y área táctil de 48px.

## Estados interactivos (`interactive/*` es de web)

`interactive/*` son los estados de **web**: hover, pressed y foco. En los temas mobile (**User App**, **Nitro**) valen **N/A** a propósito: en la app no hay hover ni foco de teclado. En los temas web (RT App, Cargo, Pay, Merchants, Portal Partners…) sí apuntan a un primitivo.

- **Mobile (User App, este kit):** no diseñes hover ni foco. El feedback al tocar es el del componente nativo.
- **Web:** hover/pressed → `interactive/bg-<fondo>-hover` / `-pressed` según el fondo del elemento (`standard`, `mild`, `weak`, `accent`, `inverse`). Foco → `interactive/border-focus` (o `interactive/border-accent-focus` sobre acento). Este kit trae solo User App, así que **lee los valores del tema web en Figma** (MCP) o pídelos; no los inventes.
- No existen `line/border-focus` ni `interactive/focus`: el de foco es `interactive/border-focus`.
- **Disabled:** es un **estado**, no una variante. `background/disabled` + `ink/disabled`.

## Accesibilidad (mínimos WCAG 2.2 AA)

- Texto normal 4.5:1 · texto grande y elementos de UI 3:1.
- `ink/accent`, `ink/error`, `ink/warning` e `ink/recommendation` **no pasan 4.5:1** en texto de cuerpo. Úsalos en íconos, texto grande o acompañados de ícono.
- **Botón primario:** respeta el componente oficial (`ink/inverse-on`), pero en revisiones de accesibilidad **señala** el 2.2:1. Alternativa que pasa: `ink/strong-on` (9.6:1).
- Nunca comuniques un estado solo con color: suma ícono o texto.

## Flujo de trabajo

**Antes de diseñar**, identifica el pedido y lee **solo** lo necesario:

| Pedido | Lee |
|---|---|
| Elegir o revisar colores, contraste | `references/colors.md` |
| Jerarquía de texto, text styles, escala por breakpoint | `references/typography.md` |
| Layout, márgenes, grilla | `references/spacing-shape.md` + `references/site/foundations/layout.md` |
| Radios de card | `references/spacing-shape.md` (tokens) + `site/foundations/cards-border-radius.md` (criterio) |
| Sombras y elevación | `references/site/foundations/elevation.md` (⚠️ sin tokens) |
| Botón (variantes, tamaños, props) | `references/components.md` + `references/site/components/button.md` |
| Card, chip, input, alert, modal, skeleton | `references/components.md` |
| HTML / CSS / React | `references/code-usage.md` + `assets/tokens.css` |
| Iconos | `references/site/foundations/icons.md` |
| Ilustraciones 3D | `references/site/foundations/illustrations-3d.md` |
| Animación y transiciones | `references/site/foundations/motion.md` |
| Vibración / feedback háptico | `references/site/foundations/haptics.md` (borrador) |
| Revisión de accesibilidad | `references/site/foundations/accessibility.md` |
| Copies, microcopy, errores, CTAs | `references/voice-and-tone.md` (secciones "Microcopy", "Botones / Links", "Escenarios de error") |
| **Copies para repartidores (Soy Rappi)** | `references/voice-and-tone.md`, sección **"Palabras con restricción de uso"**. Obligatorio: hay riesgo legal |
| Principios para defender una decisión | `references/site/principles/design-principles.md` |
| Valor exacto que no aparece arriba | `assets/rappi-design-tokens.json` |

**Patrones de flujo** (`references/site/patterns/`), léelos cuando diseñes esa pantalla o flujo:

| Diseñas… | Archivo |
|---|---|
| Agregar al carrito, stepper de cantidad | `add-product.md` |
| Modales, bottom sheets, pantallas completas | `modality.md` |
| Diálogos de confirmación | `dialogs.md` |
| Pantallas vacías o de error | `empty-states.md` |
| Estados de carga | `loading-skeleton.md` |
| Búsqueda y resultados | `search.md` |
| Login, onboarding, ajustes | `login.md`, `onboarding.md`, `settings.md` |
| Paso del home o menú a una tienda | `transitions-to-stores.md` |

**Al hacer un mockup o prototipo HTML:**

1. Pega el contenido de `assets/tokens.css` dentro de un `<style>` (no enlaces archivos externos) y usa solo variables `--rp-*`. Para texto, usa las clases de text style (`.rp-text-body-regular`, `.rp-text-h2-medium`…).
2. Fuente: `font-family: "PP Object Sans", "Inter", system-ui, sans-serif;` (PP Object Sans no está en Google Fonts; Inter es el fallback visual).
3. Diseña mobile-first (360–390px de ancho) salvo que pidan otra cosa.
4. Cubre estados: default, hover, pressed, focus, disabled, loading (skeleton), vacío y error.
5. Copies en español LatAm, tuteo, frases cortas y verbos de acción.

**Al entregar**, añade una tabla corta "Tokens usados" (elemento → token) y lista cualquier "⚠️ sin token oficial" que hayas usado.

## Voz de Rappi en 5 reglas

- Cercana, informal y directa. Habla de **tú**.
- Frases cortas, verbo primero en CTAs ("Pide ya", "Agrega a tu carrito").
- Cero tecnicismos y cero traducciones literales del inglés.
- En errores: qué pasó + qué hacer ahora, sin culpar al usuario.
- Si hay duda, da 2 o 3 variantes y explica el porqué de cada una.

## Críticas de diseño

Sé directo: señala hex hardcodeados, tokens inexistentes o mal usados (ej. `ink/accent` en texto de cuerpo, `ink/strong` sobre `background/offer`), Archivo Black fuera de `banner-bigFont`, áreas táctiles menores a 48px, estados faltantes, jerarquía confusa y copies que no suenan a Rappi. Siempre con alternativa concreta.

## Lo que aún está en construcción

- Los valores de `interactive/*` de los temas web no vienen en este kit (solo User App, donde son N/A).
- **Radius:** semánticos solo `card` (24) y `pill`. Hay escala primitiva (2 a 32…) sin semántico: si necesitas otro radio, usa el primitivo más cercano y **dilo**. El sitio los llama `borderRadius1…8`: son nombres heredados.
- **Stroke:** tokens `none` / `standard` (1) / `selected` (2). El sitio nombra `strokeSmall` (0.5), sin token.
- **Elevación:** el sitio define 4 niveles (Elevated, Strong, Hard, -Y) y sombras de botón (Green, Rappi), pero **no hay tokens ni valores** exportados. Nómbralos por nivel y marca "⚠️ sin token oficial".
- **Tipografía:** en Tablet `h1`–`h4` son menores que en Mobile, y algunos text styles tienen variables mal ligadas en Figma (ver "Revisión pendiente en Figma" en `references/typography.md`). Confirma con el equipo de DS antes de asumirlos.
- **Temas:** solo User App; hay 12 temas de producto más en Figma (RT App, Aliados, Pay, Cargo…).
- **Componentes:** solo Button tiene ficha completa. Para anatomía exacta de otros, léelos en Figma con `rappi-component-docs`.

## Guías del sistema (sitio Mustache)

Generadas desde el sitio de documentación. Léelas cuando el pedido toque ese tema; no las cargues todas.

**Tokens y temas**

- `references/site/tokens/tokens-temas.md`: Tokens y temas. Un mismo nombre de token funciona en 13 productos, en light y dark, y en tres tamaños de pantalla. Aquí está cómo: las capas, cómo se nombra un token, los temas y cómo elegir el correcto.

**Foundations**

- `references/site/foundations/accessibility.md`: Accessibility. Cómo Mustache garantiza que cualquier persona, sin importar su capacidad visual, motriz, auditiva o cognitiva, pueda usar Rappi. No es un checklist al final: es la base que sostiene color, tipografía, iconografía y spacing.
- `references/site/foundations/cards-border-radius.md`: Cards/Border Radius. El uso de tarjetas o contenedores en nuestros diseños es la manera más sencilla de integrar y organizar imágenes, textos, botones y listas.
- `references/site/foundations/colors.md`: Colors. El color es el lenguaje visual de Mustache. Cada tono tiene un propósito: comunicar identidad de marca, jerarquía, estados de feedback y accesibilidad.
- `references/site/foundations/elevation.md`: Elevation. Las elevaciones simulan el efecto visual de un elemento "flotando" sobre una superficie: sombras y orientaciones con un uso definido.
- `references/site/foundations/haptics.md`: Haptics. Cómo Mustache usa la vibración del dispositivo para confirmar, advertir y dar textura física a las interacciones de Rappi, siempre de forma consistente y como refuerzo de lo que la persona ya ve y oye.
- `references/site/foundations/icons.md`: Icons. Guía de estilo de iconografía del Mustache Design System: cómo construir, nombrar y usar los íconos de Rappi de forma consistente.
- `references/site/foundations/illustrations-3d.md`: Illustrations 3D's. Mustache utiliza un estilo de ilustración preciso para ayudar a los usuarios a comprender rápida y claramente cómo funcionan las cosas en cada experiencia.
- `references/site/foundations/layout.md`: Layout. En Rappi todos los diseños deben tener como principio el uso correcto de los elementos y espacios, para crear consistencia y claridad en la marca.
- `references/site/foundations/motion.md`: Motion. El movimiento puede dar vida a la pantalla, guiar a los usuarios a través de experiencias complejas y ayudarlos a progresar.
- `references/site/foundations/stroke.md`: Stroke. El objeto para definir el color, el ancho y el estilo de un borde o divisor.
- `references/site/foundations/typography.md`: Typography. La tipografía da voz al sistema. Una familia para la interfaz, dos pesos y una escala por breakpoint que mantiene la jerarquía consistente en toda la app.

**Patterns**

- `references/site/patterns/add-product.md`: Add Product. Agregar los productos a la canasta en Rappi, al igual que como se hace en la vida real, es una de las experiencias que nos hace diferentes e innovadores.
- `references/site/patterns/dialogs.md`: Dialogs. En nuestra interfaz, un diálogo es una “conversación” entre el sistema y las personas usuarias con el fin de solicitar o brindar información.
- `references/site/patterns/empty-states.md`: Empty states. Pantallas en nuestra interfaz o sistema que no contienen información, o que informan sobre alguna falla o error.
- `references/site/patterns/loading-skeleton.md`: Loading / Skeleton. Elementos visuales que comunican a las personas usuarias la continuidad de un proceso en la interfaz o sistema.
- `references/site/patterns/login.md`: Login. El inicio de sesión en un sistema es la acción que permite a las personas usuarias tener acceso a una app o programa.
- `references/site/patterns/modality.md`: Modality. Soluciones gráficas que, a través de un diseño fluido y sencillo, presentan el contenido de una manera clara que facilita la toma de decisiones.
- `references/site/patterns/onboarding.md`: Onboarding. Brindarle a nuestras personas usuarias una primera experiencia sencilla, rápida e intuitiva en nuestra app nos acercará a cautivarlos.
- `references/site/patterns/search.md`: Search. El principal objetivo de nuestros usuarios está en encontrar de manera rápida y sencilla aquello que necesitan en minutos.
- `references/site/patterns/settings.md`: Settings. Las personas prefieren las aplicaciones que se adaptan cada vez mejor a sus necesidades a través de sus ajustes personalizados.
- `references/site/patterns/transitions-to-stores.md`: Transitions to stores. Conoce de manera detallada cómo ocurren las transiciones desde el Menú hacia una tienda dentro de la app.

**Components**

- `references/site/components/button.md`: Button. Dispara la acción que la persona quiere hacer: pedir, pagar, confirmar, agregar. En Figma es el componente `flexible`: 3 estilos, 5 tamaños, 4 estados, y puede llevar ícono a la izquierda, a la derecha o solo ícono.
- `references/site/components/horizontal-matrix-layout.md`: Horizontal matrix layout. Fila con scroll horizontal que agrupa los accesos a las verticales de Rappi: 2 chips promocionales grandes y una serie de tiles de tienda.
- `references/site/components/modal-sheets.md`: Modal sheets. Panel que sube desde abajo, sobre un fondo oscuro, para mostrar una tarea o información sin sacar a la persona de la pantalla en la que está.

**Principios de diseño**

- `references/site/principles/design-principles.md`: Principios de Diseño. Los principios de producto son la base de la marca en el área de diseño. Con ellos no solo creamos una marca atractiva, sino una consistente y escalable que responde a las necesidades de las personas usuarias y de nuestro negocio.

